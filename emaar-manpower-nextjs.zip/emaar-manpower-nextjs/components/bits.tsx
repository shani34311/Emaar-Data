import { STATUS_LABEL, type Status } from "@/lib/types";

const STYLE: Record<Status, string> = {
  valid: "bg-bull/15 text-bull ring-bull/40",
  soon: "bg-warn/15 text-warn ring-warn/40",
  expired: "bg-bear/15 text-bear ring-bear/40",
};

export function StatusTag({ status }: { status: Status }) {
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-bold ring-1 ${STYLE[status]}`}>{STATUS_LABEL[status]}</span>;
}

export const STATUS_TEXT: Record<Status, string> = { valid: "text-bull", soon: "text-warn", expired: "text-bear" };
export const STATUS_BG: Record<Status, string> = { valid: "bg-bull", soon: "bg-warn", expired: "bg-bear" };
