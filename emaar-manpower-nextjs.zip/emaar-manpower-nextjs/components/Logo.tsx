export default function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-3">
      <svg width={compact ? 30 : 38} height={compact ? 30 : 38} viewBox="0 0 64 64" aria-hidden="true">
        <path d="M32 6 54 19v26L32 58 10 45V19z" fill="rgba(212,175,55,0.08)" stroke="#d4af37" strokeWidth="3" strokeLinejoin="round" />
        <path d="m21 32 8 8 15-17" fill="none" stroke="#ecd27b" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className="leading-none">
        <span className="h-display block text-[19px] text-bone">EMAAR</span>
        <span className="mt-1 block font-mono text-[10px] tracking-[0.32em] text-gold">AREENA</span>
      </span>
    </span>
  );
}
