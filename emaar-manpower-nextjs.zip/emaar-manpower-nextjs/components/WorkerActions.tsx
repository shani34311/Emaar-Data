"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ErrorLine, Field, Modal, api, useToast } from "./ui";
import { StatusTag } from "./bits";
import { addDays, daysLeft, fmtDate, statusOf } from "@/lib/time";
import { RELEASE_REASONS, ROLE_RANK, SHIFTS, type Role, type Worker } from "@/lib/types";

type Dlg =
  | { kind: "add" }
  | { kind: "edit"; w: Worker }
  | { kind: "renew"; w: Worker }
  | { kind: "release"; w: Worker }
  | { kind: "remove"; w: Worker }
  | { kind: "restore"; w: Worker }
  | { kind: "detail"; w: Worker }
  | null;

type Ctx = {
  role: Role; today: string; windowDays: number;
  add(): void; edit(w: Worker): void; renew(w: Worker): void; release(w: Worker): void; remove(w: Worker): void; restore(w: Worker): void; detail(w: Worker): void;
};
const WorkerCtx = createContext<Ctx | null>(null);
export const useWorkerActions = () => {
  const c = useContext(WorkerCtx);
  if (!c) throw new Error("WorkerActionsProvider is missing");
  return c;
};

export function WorkerActionsProvider({ role, today, windowDays, foremen, positions, children }: {
  role: Role; today: string; windowDays: number; foremen: string[]; positions: string[]; children: React.ReactNode;
}) {
  const [dlg, setDlg] = useState<Dlg>(null);
  const close = useCallback(() => setDlg(null), []);
  const ctx = useMemo<Ctx>(() => ({
    role, today, windowDays,
    add: () => setDlg({ kind: "add" }),
    edit: (w) => setDlg({ kind: "edit", w }),
    renew: (w) => setDlg({ kind: "renew", w }),
    release: (w) => setDlg({ kind: "release", w }),
    remove: (w) => setDlg({ kind: "remove", w }),
    restore: (w) => setDlg({ kind: "restore", w }),
    detail: (w) => setDlg({ kind: "detail", w }),
  }), [role, today, windowDays]);

  const title = dlg ? { add: "Add worker", edit: "Edit worker", renew: "Update iqama", release: "Release worker", remove: "Delete worker", restore: "Restore worker", detail: dlg.kind === "detail" ? dlg.w.name : "" }[dlg.kind] : "";

  return (
    <WorkerCtx.Provider value={ctx}>
      {children}
      <Modal open={!!dlg} onClose={close} title={title} wide={dlg?.kind === "add" || dlg?.kind === "edit" || dlg?.kind === "detail"}>
        {dlg?.kind === "add" && <WorkerForm foremen={foremen} positions={positions} onDone={close} />}
        {dlg?.kind === "edit" && <WorkerForm w={dlg.w} foremen={foremen} positions={positions} onDone={close} />}
        {dlg?.kind === "renew" && <RenewForm w={dlg.w} today={today} onDone={close} />}
        {dlg?.kind === "release" && <ReleaseForm w={dlg.w} today={today} onDone={close} />}
        {dlg?.kind === "remove" && <ConfirmForm w={dlg.w} onDone={close} mode="remove" />}
        {dlg?.kind === "restore" && <ConfirmForm w={dlg.w} onDone={close} mode="restore" />}
        {dlg?.kind === "detail" && <Detail w={dlg.w} today={today} windowDays={windowDays} />}
      </Modal>
    </WorkerCtx.Provider>
  );
}

/** Row buttons, shown according to the signed-in user's role. */
export function WorkerButtons({ w, released = false }: { w: Worker; released?: boolean }) {
  const a = useWorkerActions();
  const manager = ROLE_RANK[a.role] >= ROLE_RANK.manager;
  const admin = a.role === "admin";
  if (!manager && !admin) return null;
  return (
    <span className="inline-flex flex-wrap gap-1.5 in-[td]:flex-nowrap">
      {manager && !released && <button className="btn-ghost btn-xs" onClick={() => a.edit(w)}>Edit</button>}
      {manager && !released && <button className="btn-ghost btn-xs" onClick={() => a.renew(w)}>Update iqama</button>}
      {manager && !released && <button className="btn-ghost btn-xs" onClick={() => a.release(w)}>Release</button>}
      {manager && released && <button className="btn-ghost btn-xs" onClick={() => a.restore(w)}>Restore</button>}
      {admin && <button className="btn-danger btn-xs" onClick={() => a.remove(w)}>Delete</button>}
    </span>
  );
}

export function NameButton({ w }: { w: Worker }) {
  const a = useWorkerActions();
  return <button className="text-left font-semibold text-gold-soft hover:underline" onClick={() => a.detail(w)}>{w.name}</button>;
}

/* ------------------------------------------------------------------ forms */

function useSubmit(onDone: () => void, okText: string | ((r: any) => string)) {
  const router = useRouter();
  const toast = useToast();
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  async function run(fn: () => Promise<any>) {
    setBusy(true);
    setErr(null);
    try {
      const r = await fn();
      toast(typeof okText === "function" ? okText(r) : okText);
      onDone();
      router.refresh();
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  }
  return { err, busy, run };
}

function WorkerForm({ w, foremen, positions, onDone }: { w?: Worker; foremen: string[]; positions: string[]; onDone: () => void }) {
  const [v, setV] = useState({
    iqama: w?.iqama ?? "", name: w?.name ?? "", position: w?.position ?? "", expiry: w?.expiry ?? "", shift: w?.shift ?? "Day shift",
    foreman: w?.foreman ?? "", nationality: w?.nationality ?? "", mobile: w?.mobile ?? "", remarks: w?.remarks ?? "",
  });
  const { err, busy, run } = useSubmit(onDone, w ? "Worker updated." : "Worker added.");
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setV({ ...v, [k]: e.target.value });
  return (
    <form className="grid gap-4 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); run(() => (w ? api(`/api/workers/${w.id}`, "PATCH", v) : api("/api/workers", "POST", v))); }}>
      {w && <p className="text-xs text-dim sm:col-span-2">To renew an iqama, use “Update iqama” so the renewal is recorded in the history.</p>}
      <Field label="Iqama No"><input className="input" name="iqama" required inputMode="numeric" maxLength={10} pattern="\d{10}" title="Exactly 10 digits" value={v.iqama} onChange={set("iqama")} autoFocus /></Field>
      <Field label="Name"><input className="input" name="name" required maxLength={100} value={v.name} onChange={set("name")} /></Field>
      <Field label="Position">
        <input className="input" name="position" required maxLength={60} list="dl-pos" value={v.position} onChange={set("position")} />
        <datalist id="dl-pos">{positions.map((p) => <option key={p} value={p} />)}</datalist>
      </Field>
      <Field label="Iqama expiry date"><input className="input" name="expiry" type="date" required value={v.expiry} onChange={set("expiry")} /></Field>
      <Field label="Shift">
        <select className="input" name="shift" value={v.shift} onChange={set("shift")}>{SHIFTS.map((s) => <option key={s}>{s}</option>)}</select>
      </Field>
      <Field label="Foreman name" hint="Pick an existing foreman or type a new name.">
        <input className="input" name="foreman" required maxLength={60} list="dl-fore" autoComplete="off" value={v.foreman} onChange={set("foreman")} />
        <datalist id="dl-fore">{foremen.map((f) => <option key={f} value={f} />)}</datalist>
      </Field>
      <Field label="Nationality (optional)"><input className="input" name="nationality" maxLength={40} value={v.nationality} onChange={set("nationality")} /></Field>
      <Field label="Mobile (optional)"><input className="input" name="mobile" inputMode="tel" maxLength={20} value={v.mobile} onChange={set("mobile")} /></Field>
      <Field label="Remarks (optional)" className="sm:col-span-2"><textarea className="input min-h-20" name="remarks" maxLength={300} value={v.remarks} onChange={set("remarks")} /></Field>
      <div className="sm:col-span-2"><ErrorLine text={err} /></div>
      <div className="flex gap-2 sm:col-span-2">
        <button className="btn-gold" disabled={busy}>{busy ? "Saving…" : w ? "Update worker" : "Save worker"}</button>
        <button type="button" className="btn-ghost" onClick={onDone}>Cancel</button>
      </div>
    </form>
  );
}

function WhoLine({ w }: { w: Worker }) {
  return <p className="mb-4 text-sm text-mute"><span className="font-semibold text-bone">{w.name}</span> · {w.iqama} · Foreman: {w.foreman}</p>;
}

function RenewForm({ w, today, onDone }: { w: Worker; today: string; onDone: () => void }) {
  const [d, setD] = useState("");
  const min = addDays(daysLeft(w.expiry, today) >= 0 ? w.expiry : today, 1);
  const { err, busy, run } = useSubmit(onDone, () => `Iqama updated for ${w.name}. New expiry ${fmtDate(d)}.`);
  return (
    <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/workers/${w.id}/renew`, "POST", { new_expiry: d })); }}>
      <WhoLine w={w} />
      <p className="text-sm text-mute">Current expiry: <b className="text-bone">{fmtDate(w.expiry)}</b></p>
      <Field label="New iqama expiry date"><input className="input" type="date" required min={min} value={d} onChange={(e) => setD(e.target.value)} autoFocus /></Field>
      <ErrorLine text={err} />
      <div className="flex gap-2">
        <button className="btn-gold" disabled={busy}>{busy ? "Saving…" : "Save new expiry"}</button>
        <button type="button" className="btn-ghost" onClick={onDone}>Cancel</button>
      </div>
    </form>
  );
}

function ReleaseForm({ w, today, onDone }: { w: Worker; today: string; onDone: () => void }) {
  const [date, setDate] = useState(today);
  const [reason, setReason] = useState("");
  const { err, busy, run } = useSubmit(onDone, `${w.name} released.`);
  return (
    <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); run(() => api(`/api/workers/${w.id}/release`, "POST", { date, reason })); }}>
      <WhoLine w={w} />
      <Field label="Release date"><input className="input" type="date" required value={date} onChange={(e) => setDate(e.target.value)} /></Field>
      <Field label="Reason">
        <input className="input" required maxLength={200} list="dl-reason" autoComplete="off" placeholder="e.g. Resigned" value={reason} onChange={(e) => setReason(e.target.value)} autoFocus />
        <datalist id="dl-reason">{RELEASE_REASONS.map((r) => <option key={r} value={r} />)}</datalist>
      </Field>
      <ErrorLine text={err} />
      <div className="flex gap-2">
        <button className="btn-gold" disabled={busy}>{busy ? "Saving…" : "Confirm release"}</button>
        <button type="button" className="btn-ghost" onClick={onDone}>Cancel</button>
      </div>
    </form>
  );
}

function ConfirmForm({ w, mode, onDone }: { w: Worker; mode: "remove" | "restore"; onDone: () => void }) {
  const { err, busy, run } = useSubmit(onDone, mode === "remove" ? "Worker deleted." : `${w.name} restored.`);
  return (
    <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); run(() => (mode === "remove" ? api(`/api/workers/${w.id}`, "DELETE") : api(`/api/workers/${w.id}/restore`, "POST", {}))); }}>
      <WhoLine w={w} />
      {mode === "remove"
        ? <p className="text-sm text-mute">Permanently delete this worker and all their history? This cannot be undone. To keep a record, use <b className="text-bone">Release</b> instead.</p>
        : <p className="text-sm text-mute">Move this worker back to the active workers?</p>}
      <ErrorLine text={err} />
      <div className="flex gap-2">
        <button className={mode === "remove" ? "btn-danger" : "btn-gold"} disabled={busy}>{busy ? "Please wait…" : mode === "remove" ? "Delete permanently" : "Restore"}</button>
        <button type="button" className="btn-ghost" onClick={onDone}>Cancel</button>
      </div>
    </form>
  );
}

type Hist = { old_expiry: string | null; new_expiry: string; renewed_on: string; by_user: string | null };
function Detail({ w, today, windowDays }: { w: Worker; today: string; windowDays: number }) {
  const [hist, setHist] = useState<Hist[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    api<{ history: Hist[] }>(`/api/workers/${w.id}/history`).then((r) => alive && setHist(r.history)).catch((e) => alive && setErr(e.message));
    return () => { alive = false; };
  }, [w.id]);
  const rows: [string, string][] = [
    ["Iqama No", w.iqama], ["Position", w.position], ["Foreman", w.foreman], ["Shift", w.shift],
    ["Iqama expiry", `${fmtDate(w.expiry)} (${daysLeft(w.expiry, today)} days)`],
    ["Nationality", w.nationality || "-"], ["Mobile", w.mobile || "-"], ["Remarks", w.remarks || "-"],
  ];
  if (w.released_on) rows.push(["Released", fmtDate(w.released_on)], ["Release reason", w.release_reason || "-"]);
  return (
    <div className="space-y-5">
      <div>{w.released_on ? <span className="rounded-full bg-white/10 px-2.5 py-0.5 text-[11px] font-bold text-mute ring-1 ring-white/20">Released</span> : <StatusTag status={statusOf(w.expiry, today, windowDays)} />}</div>
      <dl className="grid gap-x-4 gap-y-2 text-sm sm:grid-cols-[140px_1fr]">
        {rows.map(([k, val]) => (<div key={k} className="contents"><dt className="text-mute">{k}</dt><dd className="break-words font-semibold text-bone">{val}</dd></div>))}
      </dl>
      <div>
        <h3 className="label">Iqama update history</h3>
        {err ? <ErrorLine text={err} /> : hist === null ? <p className="text-sm text-dim">Loading…</p> : hist.length === 0 ? <p className="text-sm text-dim">No updates recorded yet.</p> : (
          <div className="overflow-x-auto rounded-xl border border-line">
            <table className="w-full text-sm">
              <thead><tr><th className="th">Updated on</th><th className="th">Old expiry</th><th className="th">New expiry</th><th className="th">By</th></tr></thead>
              <tbody>{hist.map((h, i) => (<tr key={i}><td className="td">{fmtDate(h.renewed_on)}</td><td className="td">{fmtDate(h.old_expiry)}</td><td className="td">{fmtDate(h.new_expiry)}</td><td className="td text-mute">{h.by_user}</td></tr>))}</tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
