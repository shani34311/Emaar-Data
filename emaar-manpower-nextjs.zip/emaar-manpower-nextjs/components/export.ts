import { daysLeft, fmtDate, statusOf } from "@/lib/time";
import { STATUS_LABEL, type Worker } from "@/lib/types";
import { countWorkers } from "@/lib/stats";

function csvSafe(v: unknown) {
  const s = String(v ?? "");
  // Stops spreadsheet programs from running text that starts like a formula.
  return /^[=@]|^[+\-][^\d\s().\-]/.test(s) ? "'" + s : s;
}

export function download(blob: Blob, name: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 600);
}

export function csvFile(name: string, rows: unknown[][]) {
  const text = "﻿" + rows.map((r) => r.map((v) => `"${csvSafe(v).replace(/"/g, '""')}"`).join(",")).join("\r\n");
  download(new Blob([text], { type: "text/csv;charset=utf-8" }), name);
}

export function exportWorkersCsv(list: Worker[], name: string, today: string, win: number, released = false) {
  const head = ["Iqama No", "Name", "Position", "Foreman", "Shift", "Expiry", "Days left", "Status", "Nationality", "Mobile", "Remarks"];
  if (released) head.push("Release date", "Release reason");
  csvFile(name, [head, ...list.map((w) => {
    const r: unknown[] = [w.iqama, w.name, w.position, w.foreman, w.shift, w.expiry, released ? "" : daysLeft(w.expiry, today), released ? "Released" : STATUS_LABEL[statusOf(w.expiry, today, win)], w.nationality, w.mobile, w.remarks];
    if (released) r.push(w.released_on, w.release_reason);
    return r;
  })]);
}

export async function exportWorkersPdf(list: Worker[], title: string, today: string, win: number) {
  const { jsPDF } = await import("jspdf");
  const autoTable = (await import("jspdf-autotable")).default;
  const c = countWorkers(list, today, win);
  const doc = new jsPDF({ orientation: "landscape" });
  doc.setFontSize(15);
  doc.text(title, 14, 14);
  doc.setFontSize(9);
  doc.setTextColor(100);
  doc.text(`Generated ${fmtDate(today)}  |  Workers: ${c.total}  Valid: ${c.valid}  Expiring soon: ${c.soon}  Expired: ${c.expired}`, 14, 20);
  autoTable(doc, {
    startY: 26,
    head: [["Iqama No", "Name", "Position", "Foreman", "Shift", "Expiry", "Days left", "Status"]],
    body: list.map((w) => [w.iqama, w.name, w.position, w.foreman, w.shift, fmtDate(w.expiry), String(daysLeft(w.expiry, today)), STATUS_LABEL[statusOf(w.expiry, today, win)]]),
    styles: { fontSize: 8, cellPadding: 3 },
    headStyles: { fillColor: [34, 34, 34], textColor: 255 },
    didParseCell: (d) => {
      if (d.section === "body" && d.column.index === 7) {
        const s = statusOf(list[d.row.index].expiry, today, win);
        d.cell.styles.fontStyle = "bold";
        if (s === "expired") { d.cell.styles.fillColor = [192, 57, 43]; d.cell.styles.textColor = [255, 255, 255]; }
        else if (s === "soon") { d.cell.styles.fillColor = [224, 138, 0]; d.cell.styles.textColor = [255, 255, 255]; }
        else d.cell.styles.textColor = [29, 122, 68];
      }
    },
  });
  doc.save(`manpower-${today}.pdf`);
}

/** Minimal CSV reader (handles quotes, commas or semicolons). */
export function parseCsv(text: string): string[][] {
  text = text.replace(/^﻿/, "");
  const first = text.split(/\r?\n/)[0] || "";
  const delim = !first.includes(",") && first.includes(";") ? ";" : ",";
  const rows: string[][] = [];
  let row: string[] = [], f = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === delim) { row.push(f); f = ""; }
    else if (c === "\n") { row.push(f); rows.push(row); row = []; f = ""; }
    else if (c !== "\r") f += c;
  }
  if (f !== "" || row.length) { row.push(f); rows.push(row); }
  return rows.filter((r) => r.some((x) => x.trim() !== ""));
}
