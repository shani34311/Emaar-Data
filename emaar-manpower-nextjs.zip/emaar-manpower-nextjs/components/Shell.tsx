"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Logo from "./Logo";
import { ROLE_LABEL, type Role } from "@/lib/types";

export type NavItem = { href: string; label: string; icon: string; badge?: number; tone?: "bad" | "warn" | "mute" };

const TONE = { bad: "bg-bear text-white", warn: "bg-warn text-ink", mute: "bg-white/10 text-mute" };

export default function Shell({ title, user, links, adminLinks, children }: {
  title: string; user: { name: string; email: string; role: Role }; links: NavItem[]; adminLinks: NavItem[]; children: React.ReactNode;
}) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);

  async function logout() {
    await fetch("/api/logout", { method: "POST" });
    window.location.href = "/login";
  }
  const active = (h: string) => path === h || path.startsWith(h + "/");

  const Item = ({ l }: { l: NavItem }) => (
    <Link href={l.href} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${active(l.href) ? "bg-gold/12 text-gold ring-1 ring-gold/30" : "text-bone/75 hover:bg-white/5 hover:text-bone"}`} aria-current={active(l.href) ? "page" : undefined}>
      <span className="w-5 text-center text-gold/80" aria-hidden="true">{l.icon}</span>
      <span className="flex-1">{l.label}</span>
      {l.badge !== undefined && l.badge > 0 && <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${TONE[l.tone ?? "mute"]}`}>{l.badge}</span>}
    </Link>
  );

  return (
    <div className="no-print min-h-screen">
      <header className="sticky top-0 z-40 flex h-16 items-center gap-3 border-b border-line bg-ink/95 px-4 backdrop-blur sm:px-6">
        <button onClick={() => setOpen((v) => !v)} className="rounded-full border border-line-strong px-3.5 py-1.5 text-sm text-gold lg:hidden" aria-expanded={open} aria-label="Menu">{open ? "Close" : "Menu"}</button>
        <Link href="/dashboard" className="hidden sm:block"><Logo compact /></Link>
        <h1 className="h-display min-w-0 flex-1 truncate text-[17px] text-bone sm:text-xl">{title}</h1>
        <div className="hidden text-right text-xs leading-tight sm:block">
          <p className="font-semibold text-bone">{user.name}</p>
          <p className="text-mute">{ROLE_LABEL[user.role]}</p>
        </div>
        <button onClick={logout} className="btn-ghost btn-sm">Sign out</button>
      </header>
      <div className="lg:grid lg:grid-cols-[240px_1fr]">
        <aside className={`border-r border-line bg-ink-2 lg:sticky lg:top-16 lg:block lg:h-[calc(100vh-4rem)] lg:overflow-y-auto ${open ? "block" : "hidden"}`}>
          <nav className="flex flex-col gap-1 px-3 py-4" aria-label="Main">
            {links.map((l) => <Item key={l.href} l={l} />)}
            {adminLinks.length > 0 && <p className="mt-5 px-3 pb-1 text-[11px] font-semibold uppercase tracking-wider text-dim">Admin panel</p>}
            {adminLinks.map((l) => <Item key={l.href} l={l} />)}
            <p className="mt-5 px-3 pb-1 text-[11px] font-semibold uppercase tracking-wider text-dim">Account</p>
            <Item l={{ href: "/account", label: "My account", icon: "☺" }} />
          </nav>
          <p className="truncate px-6 pb-6 text-xs text-dim">{user.email}</p>
        </aside>
        <main className="min-w-0 px-4 py-8 sm:px-8 lg:py-10">{children}</main>
      </div>
    </div>
  );
}
