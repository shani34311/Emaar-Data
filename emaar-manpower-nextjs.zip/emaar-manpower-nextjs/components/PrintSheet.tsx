"use client";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { daysLeft, fmtDate, statusOf } from "@/lib/time";
import { STATUS_LABEL, type Worker } from "@/lib/types";
import { countWorkers } from "@/lib/stats";

export type PrintGroup = { heading: string; workers: Worker[]; signature?: boolean };
const CLS = { valid: "s-ok", soon: "s-warn", expired: "s-bad" } as const;

/** Shows a print-only copy of the lists, opens the print window, then reports back when done. */
export default function PrintSheet({ title, groups, today, windowDays, withForeman, onDone }: {
  title: string; groups: PrintGroup[]; today: string; windowDays: number; withForeman: boolean; onDone: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (!mounted) return;
    const t = setTimeout(() => window.print(), 120);
    window.addEventListener("afterprint", onDone);
    return () => { clearTimeout(t); window.removeEventListener("afterprint", onDone); };
  }, [mounted, onDone]);
  if (!mounted) return null;
  return createPortal(
    <div className="print-root">
      {groups.map((g, gi) => {
        const c = countWorkers(g.workers, today, windowDays);
        return (
          <div className="pg" key={gi}>
            <h1>{title}</h1>
            <h2>{g.heading}</h2>
            <p className="meta">
              Date: {fmtDate(today)} &nbsp;|&nbsp; Workers: {c.total} &nbsp;|&nbsp; Valid: {c.valid} &nbsp;|&nbsp; Expiring in {windowDays} days: {c.soon} &nbsp;|&nbsp; Expired: {c.expired} &nbsp;|&nbsp; Day: {c.day} / Night: {c.night}
            </p>
            <table>
              <thead>
                <tr><th>#</th><th>Iqama No</th><th>Name</th><th>Position</th>{withForeman && <th>Foreman</th>}<th>Expiry</th><th>Days left</th><th>Status</th><th>Shift</th></tr>
              </thead>
              <tbody>
                {g.workers.map((w, i) => {
                  const s = statusOf(w.expiry, today, windowDays);
                  return (
                    <tr key={w.id}>
                      <td>{i + 1}</td><td>{w.iqama}</td><td>{w.name}</td><td>{w.position}</td>{withForeman && <td>{w.foreman}</td>}
                      <td>{fmtDate(w.expiry)}</td><td>{daysLeft(w.expiry, today)}</td><td className={CLS[s]}>{STATUS_LABEL[s]}</td><td>{w.shift}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {g.signature && <p className="sign">Foreman signature: ______________________ &nbsp;&nbsp;&nbsp; Date: ______________</p>}
          </div>
        );
      })}
    </div>,
    document.body
  );
}
