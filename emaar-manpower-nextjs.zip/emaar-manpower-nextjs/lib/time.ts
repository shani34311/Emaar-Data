import type { Status } from "./types";

const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** Today's date (YYYY-MM-DD) in the given time zone. */
export function todayStr(tz = "Asia/Riyadh"): string {
  try {
    return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

export function isDateStr(s: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return false;
  const y = +m[1], mo = +m[2], d = +m[3];
  if (y < 2000 || y > 2100) return false;
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}

export function dayNum(s: string): number {
  const p = s.split("-");
  return Date.UTC(+p[0], +p[1] - 1, +p[2]) / 864e5;
}

export function addDays(s: string, n: number): string {
  const d = new Date((dayNum(s) + n) * 864e5);
  return d.toISOString().slice(0, 10);
}

export const daysLeft = (expiry: string, today: string) => Math.round(dayNum(expiry) - dayNum(today));

export function statusOf(expiry: string, today: string, windowDays: number): Status {
  const d = daysLeft(expiry, today);
  return d < 0 ? "expired" : d <= windowDays ? "soon" : "valid";
}

/** 2027-05-01 -> 01 May 2027 */
export function fmtDate(s: string | null | undefined): string {
  if (!s) return "";
  const p = s.slice(0, 10).split("-");
  return `${p[2]} ${MON[+p[1] - 1]} ${p[0]}`;
}

export function fmtDateTime(s: string | Date | null | undefined, tz = "Asia/Riyadh"): string {
  if (!s) return "Never";
  const d = typeof s === "string" ? new Date(s) : s;
  try {
    const parts = new Intl.DateTimeFormat("en-GB", { timeZone: tz, day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: false }).format(d);
    return parts.replace(",", "");
  } catch {
    return d.toISOString().slice(0, 16).replace("T", " ");
  }
}
