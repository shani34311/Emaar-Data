export type Role = "admin" | "manager" | "viewer";
export const ROLE_RANK: Record<Role, number> = { viewer: 1, manager: 2, admin: 3 };
export const ROLE_LABEL: Record<Role, string> = { admin: "Administrator", manager: "Manager", viewer: "Viewer" };

export type Shift = "Day shift" | "Night shift";
export const SHIFTS: Shift[] = ["Day shift", "Night shift"];

export type Status = "valid" | "soon" | "expired";
export const STATUS_LABEL: Record<Status, string> = { valid: "Valid", soon: "Expiring soon", expired: "Expired" };

export type Worker = {
  id: string;
  iqama: string;
  name: string;
  position: string;
  expiry: string;
  shift: Shift;
  foreman_id: string;
  foreman: string;
  nationality: string;
  mobile: string;
  remarks: string;
  released_on: string | null;
  release_reason: string | null;
  last_renewed: string | null;
  renewals: number;
};

export type Foreman = { id: string; name: string };

export type AppUser = {
  id: string; email: string; name: string; role: Role; active: boolean; created_at: string; last_login: string | null;
};

export type Settings = { siteTitle: string; expiringDays: number; timezone: string };

export const TIMEZONES = [
  "Asia/Riyadh", "Asia/Karachi", "Asia/Dubai", "Asia/Kuwait", "Asia/Qatar", "Asia/Bahrain", "Asia/Muscat", "Asia/Kolkata", "Asia/Dhaka", "Africa/Cairo", "UTC",
];

export const RELEASE_REASONS = ["Resigned", "Contract ended", "Terminated", "Transferred to another site", "Final exit", "Absconded", "Iqama expired"];
