import { cache } from "react";
import { z } from "zod";
import type { PoolClient } from "pg";
import { q } from "./db";
import { isDateStr } from "./time";
import { SHIFTS, type Worker, type Foreman } from "./types";

const SELECT = `SELECT w.id, w.iqama, w.name, w.position, w.expiry, w.shift, w.foreman_id, f.name AS foreman,
  w.nationality, w.mobile, w.remarks, w.released_on, w.release_reason,
  (SELECT max(renewed_on) FROM renewals r WHERE r.worker_id = w.id) AS last_renewed,
  (SELECT count(*)::int FROM renewals r WHERE r.worker_id = w.id) AS renewals
  FROM workers w JOIN foremen f ON f.id = w.foreman_id`;

export const listWorkers = cache(() => q<Worker>(`${SELECT} ORDER BY w.expiry, w.name`));
export const listForemen = cache(() => q<Foreman>("SELECT id, name FROM foremen ORDER BY lower(name)"));

const squash = (s: string) => s.replace(/\s+/g, " ").trim();
const text = (max: number, min = 0) => z.string().transform(squash).pipe(z.string().min(min, min ? "is required" : undefined).max(max, `can be up to ${max} characters`));
export const dateStr = z.string().trim().refine(isDateStr, "is not a valid date");

export const WorkerInput = z.object({
  iqama: z.string().transform((s) => s.replace(/\s+/g, "")).pipe(z.string().regex(/^\d{10}$/, "must be exactly 10 digits")),
  name: text(100, 2),
  position: text(60, 1),
  expiry: dateStr,
  shift: z.enum(SHIFTS as [string, ...string[]]),
  foreman: text(60, 2),
  nationality: text(40).optional().default(""),
  mobile: text(20).pipe(z.string().regex(/^[0-9+\-() ]*$/, "has invalid characters")).optional().default(""),
  remarks: text(300).optional().default(""),
});
export type WorkerInputT = z.infer<typeof WorkerInput>;

type Queryable = Pick<PoolClient, "query">;

/** Finds the foreman by name (ignoring capital letters) or creates them. */
export async function foremanId(c: Queryable, name: string): Promise<string> {
  const r = await c.query("SELECT id FROM foremen WHERE lower(name) = lower($1)", [name]);
  if (r.rows[0]) return r.rows[0].id;
  const ins = await c.query("INSERT INTO foremen (name) VALUES ($1) RETURNING id", [name]);
  return ins.rows[0].id;
}
