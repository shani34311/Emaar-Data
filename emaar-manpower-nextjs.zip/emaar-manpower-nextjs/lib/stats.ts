import { statusOf } from "./time";
import type { Worker } from "./types";

export type Counts = { total: number; valid: number; soon: number; expired: number; day: number; night: number };

export function countWorkers(list: Worker[], today: string, windowDays: number): Counts {
  const c: Counts = { total: list.length, valid: 0, soon: 0, expired: 0, day: 0, night: 0 };
  for (const w of list) {
    c[statusOf(w.expiry, today, windowDays)]++;
    if (w.shift === "Night shift") c.night++; else c.day++;
  }
  return c;
}

export function groupByForeman(list: Worker[], foremen: { id: string; name: string }[] = []) {
  const m = new Map<string, { id: string; name: string; workers: Worker[] }>();
  for (const f of foremen) m.set(f.id, { id: f.id, name: f.name, workers: [] });
  for (const w of list) {
    if (!m.has(w.foreman_id)) m.set(w.foreman_id, { id: w.foreman_id, name: w.foreman, workers: [] });
    m.get(w.foreman_id)!.workers.push(w);
  }
  return [...m.values()].sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
}
