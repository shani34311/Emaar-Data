import { z } from "zod";
import { cache } from "react";
import { q } from "./db";
import type { AppUser } from "./types";

export const UserInput = z.object({
  email: z.string().trim().toLowerCase().email("is not a valid email address").max(120),
  name: z.string().transform((s) => s.replace(/\s+/g, " ").trim()).pipe(z.string().min(2, "is required").max(60)),
  role: z.enum(["admin", "manager", "viewer"]),
  active: z.boolean().default(true),
  password: z.string().max(200).optional().transform((v) => v || "").refine((v) => v === "" || v.length >= 10, "must be at least 10 characters"),
});

export const listUsers = cache(() =>
  q<AppUser>("SELECT id, email, name, role, active, created_at::text AS created_at, last_login::text AS last_login FROM users ORDER BY lower(email)"));

export async function otherActiveAdmins(excludeId: string): Promise<number> {
  const r = await q<{ n: number }>("SELECT count(*)::int AS n FROM users WHERE role = 'admin' AND active AND id <> $1", [excludeId]);
  return r[0]?.n ?? 0;
}
