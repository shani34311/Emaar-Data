import { NextResponse } from "next/server";
import { ZodError } from "zod";

export const ok = (data: unknown = { ok: true }, status = 200) => NextResponse.json(data, { status });
export const fail = (error: string, status = 400, extra: Record<string, unknown> = {}) =>
  NextResponse.json({ error, ...extra }, { status });

const LABELS: Record<string, string> = {
  iqama: "Iqama No", name: "Name", position: "Position", expiry: "Expiry date", shift: "Shift", foreman: "Foreman name",
  nationality: "Nationality", mobile: "Mobile", remarks: "Remarks", date: "Date", reason: "Reason", new_expiry: "New expiry date",
  email: "Email", password: "Password", role: "Role", siteTitle: "Site title", expiringDays: "Expiring-soon window", timezone: "Time zone",
};

export function handleError(e: unknown) {
  if (e instanceof ZodError) {
    const first = e.issues[0];
    const key = String(first?.path?.[0] ?? "");
    const label = LABELS[key] ?? key;
    return fail(first ? `${label ? label + ": " : ""}${first.message}` : "Invalid input", 400);
  }
  const err = e as { code?: string; constraint?: string; message?: string };
  if (err?.code === "23505") {
    if (err.constraint === "workers_active_iqama_ux") return fail("This iqama number is already added.", 409);
    if (err.constraint === "foremen_name_ux") return fail("Another foreman already has this name.", 409);
    if (err.constraint === "users_email_key") return fail("This email is already used by another user.", 409);
    return fail("That value is already in use.", 409);
  }
  if (err?.code === "23503") return fail("This item is still in use and can't be deleted.", 409);
  console.error(e);
  return fail("Something went wrong. Please try again.", 500);
}

export async function readJson(req: Request): Promise<any> {
  try {
    return await req.json();
  } catch {
    return {};
  }
}
