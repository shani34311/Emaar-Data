import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { NextResponse } from "next/server";
import { cache } from "react";
import { one } from "./db";
import { ROLE_RANK, type Role } from "./types";

export const COOKIE = "emaar_session";
const MAX_AGE = 60 * 60 * 12; // 12 hours

function secret() {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 32) throw new Error("SESSION_SECRET must be set and at least 32 characters long");
  return new TextEncoder().encode(s);
}

export type SessionUser = { id: string; email: string; name: string; role: Role };

export async function createSessionCookie(user: { sub: string }) {
  const token = await new SignJWT({})
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(user.sub)
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE}s`)
    .sign(secret());
  const jar = await cookies();
  jar.set(COOKIE, token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: MAX_AGE });
}

export async function clearSession() {
  (await cookies()).delete(COOKIE);
}

/** The signed-in user, read fresh from the database (so role changes and disabled accounts apply immediately). */
export const getUser = cache(async (): Promise<SessionUser | null> => {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret(), { algorithms: ["HS256"] });
    const u = await one<{ id: string; email: string; name: string; role: Role; active: boolean }>(
      "SELECT id, email, name, role, active FROM users WHERE id = $1", [String(payload.sub)]);
    if (!u || !u.active) return null;
    return { id: u.id, email: u.email, name: u.name, role: u.role };
  } catch {
    return null;
  }
});

/** For pages: sends visitors to the login page, or to the dashboard if their role is too low. */
export async function requireUser(min: Role = "viewer"): Promise<SessionUser> {
  const u = await getUser();
  if (!u) redirect("/login");
  if (ROLE_RANK[u.role] < ROLE_RANK[min]) redirect("/dashboard");
  return u;
}

/** For API routes: returns the user, or a 401/403 response to send back. */
export async function requireApi(req: Request, min: Role = "viewer"): Promise<SessionUser | NextResponse> {
  if (req.method !== "GET") {
    // Basic CSRF protection: changing requests must come from this site.
    const origin = req.headers.get("origin");
    const host = req.headers.get("x-forwarded-host") || req.headers.get("host");
    if (origin && host && new URL(origin).host !== host) return NextResponse.json({ error: "Invalid origin" }, { status: 403 });
  }
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Please sign in again." }, { status: 401 });
  if (ROLE_RANK[u.role] < ROLE_RANK[min]) return NextResponse.json({ error: "You do not have permission to do this." }, { status: 403 });
  return u;
}
