import { q } from "./db";

export async function logAct(user: string, action: string, detail = "") {
  try {
    await q("INSERT INTO activity (user_email, action, detail) VALUES ($1, $2, $3)", [user, action, detail.slice(0, 500)]);
    if (Math.random() < 0.02) await q("DELETE FROM activity WHERE id <= (SELECT max(id) - 5000 FROM activity)");
  } catch (e) {
    console.warn("Could not write activity log:", (e as Error).message);
  }
}
