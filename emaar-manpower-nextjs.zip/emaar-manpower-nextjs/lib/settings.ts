import { cache } from "react";
import { one } from "./db";
import type { Settings } from "./types";
// @ts-ignore — plain JS module shared with the database setup script
import { DEFAULT_SETTINGS } from "../db/seed-data.mjs";
import { todayStr } from "./time";

export const DEFAULTS = DEFAULT_SETTINGS as Settings;

export const getSettings = cache(async (): Promise<Settings> => {
  const row = await one<{ value: Partial<Settings> }>("SELECT value FROM settings WHERE id = 'main'");
  const s = { ...DEFAULTS, ...(row?.value || {}) } as Settings;
  s.expiringDays = Math.max(1, Math.min(180, Number(s.expiringDays) || 30));
  return s;
}) as () => Promise<Settings>;

export async function getToday() {
  const s = await getSettings();
  return todayStr(s.timezone);
}
