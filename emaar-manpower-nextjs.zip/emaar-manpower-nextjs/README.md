# EMAAR Manpower Dashboard (Areena)

A complete manpower and iqama tracking website with a secure admin panel.

**Built with:** Next.js 16 · React 19 · Tailwind CSS 4 · PostgreSQL (Supabase) · hosted on Vercel.
Same stack and look as your TFR website.

---

## What's inside

| Area | What it does |
|---|---|
| **Dashboard** | How many iqama are **valid**, **expiring in 30 days** and **expired**. Status chart, expiries by month, who needs action first, and workers by foreman. Click any box to see those workers. |
| **Workers** | Iqama No, Name, Position, Iqama expiry, Shift (Day / Night), Foreman (plus optional nationality, mobile, remarks). Search and filter, add, edit, **Update iqama** (asks for the new expiry date and keeps the history), **Release** (asks for date and reason), delete. Export CSV, Save as PDF (expired = red, expiring soon = orange), print. |
| **Foremen** | Workers grouped by foreman, each with their own counts. **Print** one foreman (one separate sheet each) or **Print all foremen**. Rename a foreman. |
| **Released** | Everyone who left, with release date and reason. **Restore** if someone comes back. |
| **Admin panel** | Users and roles · Activity log (who did what and when) · Backup and import (JSON backup, CSV import) · Settings (site title, expiring window, time zone) · My account (change password) |

**Roles:** Administrator = everything · Manager = add, edit, update iqama, release, restore · Viewer = only look and print.

**Security:** passwords are hashed, login cookie is signed and HTTP-only, 8 wrong attempts per 15 minutes are blocked, every change is logged, and permissions are checked on the server for every request.

---

## Try it on your computer first (easiest way)

No accounts, no database setup, no settings file.

1. **Install Node.js** (one time): https://nodejs.org → download **LTS** → install.
2. **Unzip** the package.
3. Double-click:
   - **Windows:** `START-WINDOWS.bat` (if "Windows protected your PC" appears: **More info → Run anyway**)
   - **Mac:** `START-MAC.command` (if blocked: right-click → **Open** → **Open**)
4. The first run downloads what it needs (2–5 minutes). Then your browser opens.

| | |
|---|---|
| Website | http://localhost:3000 |
| Sign in | http://localhost:3000/login |
| Email | `admin@emaar.local` |
| Password | `emaar12345` |

The first run adds **14 sample workers** so you can see how it works. To start empty, use `npm run local:empty` instead (before the first run), or delete the sample workers from the Workers page.
Your local data is kept in the `local-database` folder. This local copy is only for testing. Use the steps below for the real website.

---

## Put it on the internet (Supabase + GitHub + Vercel)

All three have free plans.

### 1. Database (Supabase)
1. Go to https://supabase.com → **New project**. Choose a strong database password and write it down. Choose a region close to you.
2. Open **Project Settings → Database → Connection string**.
3. Copy the **Transaction pooler** string (port **6543**) → this is `DATABASE_URL`.
4. Copy the **Session pooler** string (port **5432**) → this is `DIRECT_URL`.
5. Replace `[YOUR-PASSWORD]` in both with your database password.

### 2. Code (GitHub)
1. Create a free account at https://github.com and a **new private repository**.
2. Upload all files of this folder to it (do **not** upload `node_modules`, `.next` or `local-database`; the included `.gitignore` already skips them if you use Git).

### 3. Website (Vercel)
1. Go to https://vercel.com → **Add New → Project** → import your GitHub repository.
2. Before pressing Deploy, open **Environment Variables** and add (see `.env.example`):

| Name | Value |
|---|---|
| `DATABASE_URL` | Supabase transaction pooler string (port 6543) |
| `DIRECT_URL` | Supabase session pooler string (port 5432) |
| `SESSION_SECRET` | A long random text, at least 32 characters |
| `ADMIN_EMAIL` | Your email (becomes the first administrator) |
| `ADMIN_PASSWORD` | A strong password, at least 10 characters |
| `NEXT_PUBLIC_SITE_URL` | Your site address, e.g. `https://emaar-manpower.vercel.app` |

3. Press **Deploy**. The tables and the first administrator are created automatically.
4. Open `https://your-site/login`, sign in, then go to **Admin panel → Users** to add your team.
5. After the first successful sign in you can remove `ADMIN_PASSWORD` from Vercel.

### Using your own domain
Vercel → Project → **Settings → Domains** → add your domain and follow the DNS steps shown. HTTPS is automatic.

---

## Everyday use

- **Add workers:** Workers → Add worker. If the foreman is new, just type the name.
- **Many workers at once:** Admin panel → Backup & import → Download CSV template → fill in Excel → Save as CSV → import. Dates can be `2027-05-31` or `31/05/2027`. Importing twice is safe (existing iqama numbers are skipped).
- **Move data from the old single-page dashboard:** in the old file press "Save backup file", then import that `.json` file under Backup & import.
- **Iqama renewed:** Update iqama on the worker row, type the new expiry date.
- **Worker leaves:** Release, choose the date and reason. They move to Released and stop counting in the dashboard.
- **Print for a foreman:** Foremen → Print. In the print window turn on **Background graphics** so the red and orange colours print.
- **Backup:** Admin panel → Backup & import → Download backup file. Do it weekly.
- **Expiring window / time zone:** Admin panel → Settings (default 30 days, Asia/Riyadh).

---

## Troubleshooting

- **Cannot sign in:** another administrator can set a new password under Admin panel → Users → Edit. If nobody can sign in, open Supabase → Table Editor → `users`, delete all rows of that table, then redeploy on Vercel with `ADMIN_EMAIL` and `ADMIN_PASSWORD` set: a new first administrator is created (workers are not touched).
- **Deploy fails with a database error:** check `DATABASE_URL` / `DIRECT_URL` (password filled in, ports 6543 and 5432).
- **Local start says port 3000 is busy:** it automatically picks the next free port; read the address shown in the window.
- **Reset the local test copy:** close the window and delete the `local-database` folder.
