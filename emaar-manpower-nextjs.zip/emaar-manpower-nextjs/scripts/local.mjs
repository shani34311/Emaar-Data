// Runs the whole EMAAR Manpower Dashboard on your own computer — no Supabase, no .env file needed.
// It starts a private database inside the "local-database" folder, adds a few sample workers
// (first run only), starts the website and opens it in your browser.
//
//   Windows:  double-click START-WINDOWS.bat
//   Mac:      double-click START-MAC.command
//   Or:       npm run local         (with sample workers on the first run)
//             npm run local:empty   (start with an empty list)
import { spawn } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import net from "node:net";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(import.meta.url);
process.chdir(root);

const line = "─".repeat(60);
const say = (s = "") => console.log(s);

function portFree(port) {
  return new Promise((res) => {
    const s = net.createServer().once("error", () => res(false)).once("listening", () => s.close(() => res(true)));
    s.listen(port, "0.0.0.0");
  });
}
async function firstFreePort(start, tries = 20) {
  for (let p = start; p < start + tries; p++) if (await portFree(p)) return p;
  throw new Error(`No free port found near ${start}`);
}

function openBrowser(url) {
  const cmd = process.platform === "win32" ? ["cmd", ["/c", "start", "", url]] : process.platform === "darwin" ? ["open", [url]] : ["xdg-open", [url]];
  try { spawn(cmd[0], cmd[1], { stdio: "ignore", detached: true }).unref(); } catch {}
}

function lanAddress() {
  const os = require("node:os");
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) if (a.family === "IPv4" && !a.internal) return a.address;
  }
  return null;
}

let closeDb = async () => {};

async function main() {
  say(line);
  say("  EMAAR Manpower Dashboard (Areena) · local test copy");
  say(line);

  // 1) Database ------------------------------------------------------------
  const dataDir = path.join(root, "local-database");
  fs.mkdirSync(dataDir, { recursive: true });
  const env = { ...process.env };
  let db = null;
  let pgServer = null;

  if (env.DATABASE_URL) {
    say("• Using the database from your DATABASE_URL setting.");
  } else {
    let PGlite, PGLiteSocketServer;
    try {
      ({ PGlite } = await import("@electric-sql/pglite"));
      ({ PGLiteSocketServer } = await import("@electric-sql/pglite-socket"));
    } catch (e) {
      say("✗ Some files are missing. Delete the node_modules folder and double-click the start file again.");
      say("  (details: " + (e?.message || e) + ")");
      process.exit(1);
    }
    const first = !fs.existsSync(path.join(dataDir, "db", "PG_VERSION"));
    if (first) say("• First run: creating your local database…");
    // PGlite is PostgreSQL compiled to JavaScript: nothing extra to install, works on Windows, Mac and Linux.
    db = await PGlite.create({ dataDir: path.join(dataDir, "db") });
    const dbPort = await firstFreePort(54329);
    pgServer = new PGLiteSocketServer({ db, port: dbPort, host: "127.0.0.1", maxConnections: 1 });
    await pgServer.start();
    env.DATABASE_URL = env.DIRECT_URL = `postgresql://postgres:postgres@127.0.0.1:${dbPort}/postgres`;
    env.PG_POOL_MAX = "1"; // the local database takes one connection; requests wait their turn
    say("✓ Local database running");
  }

  closeDb = async () => {
    try { await pgServer?.stop(); } catch {}
    try { await db?.close(); } catch {}
  };

  // 2) Settings ------------------------------------------------------------
  const secretFile = path.join(dataDir, "session-secret.txt");
  if (!fs.existsSync(secretFile)) fs.writeFileSync(secretFile, crypto.randomBytes(32).toString("hex"));
  env.SESSION_SECRET ||= fs.readFileSync(secretFile, "utf8").trim();
  env.ADMIN_EMAIL ||= "admin@emaar.local";
  env.ADMIN_PASSWORD ||= "emaar12345";
  // Sample workers on the very first run only (never when --empty is used).
  if (!process.argv.includes("--empty") && !env.SEED_DEMO) env.SEED_DEMO = "1";
  const webPort = await firstFreePort(3000);
  const url = `http://localhost:${webPort}`;
  env.NEXT_PUBLIC_SITE_URL ||= url;
  env.NEXT_TELEMETRY_DISABLED = "1";

  // 3) Tables + menu -------------------------------------------------------
  // Must not block: the local database runs inside this same program and has to keep answering.
  const setupCode = await new Promise((res) => {
    const child = spawn(process.execPath, [path.join(root, "db", "setup.mjs")], { env, stdio: "inherit" });
    child.on("exit", (code) => res(code));
    child.on("error", () => res(1));
  });
  if (setupCode !== 0) {
    say("✗ Database setup failed (see the message above).");
    await closeDb();
    process.exit(1);
  }

  // 4) Website -------------------------------------------------------------
  say("• Starting the website (the first page can take ~20 seconds to load)…");
  const nextBin = require.resolve("next/dist/bin/next");
  const web = spawn(process.execPath, [nextBin, "dev", "-p", String(webPort)], { env, stdio: ["inherit", "pipe", "inherit"] });
  let opened = false;
  web.stdout.on("data", (buf) => {
    const text = buf.toString();
    if (!opened && /Ready|ready in|Local:/i.test(text)) {
      opened = true;
      const lan = lanAddress();
      say("");
      say(line);
      say("  ✓ THE DASHBOARD IS RUNNING");
      say("");
      say(`  Website:      ${url}`);
      say(`  Sign in:      ${url}/login`);
      say(`  Email:        ${env.ADMIN_EMAIL}`);
      say(`  Password:     ${process.env.ADMIN_PASSWORD ? "(the one you set)" : env.ADMIN_PASSWORD}`);
      if (lan) say(`  On your phone (same Wi-Fi): http://${lan}:${webPort}`);
      say("");
      say("  Keep this window open. To stop: close it or press Ctrl + C.");
      say(line);
      openBrowser(url);
    }
    if (/error/i.test(text) && !stopping) process.stdout.write(text);
  });

  let stopping = false;
  const stop = async () => {
    if (stopping) return;
    stopping = true;
    say("\nStopping…");
    if (web.exitCode === null) {
      await new Promise((res) => { web.once("exit", res); try { web.kill(); } catch { res(); } setTimeout(res, 5000); });
    }
    await closeDb();
    process.exit(0);
  };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
  process.on("SIGHUP", stop);
  web.on("exit", () => stop());
}

main().catch(async (e) => {
  console.error("\n✗ Could not start.");
  console.error(e instanceof Error ? (e.stack || e.message) : JSON.stringify(e) ?? String(e));
  console.error("\nPlease take a screenshot of this window and send it to your developer.");
  await closeDb();
  process.exit(1);
});
