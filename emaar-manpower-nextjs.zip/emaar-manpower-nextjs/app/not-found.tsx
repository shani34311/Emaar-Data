import Link from "next/link";
import Logo from "@/components/Logo";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 px-4 text-center">
      <Logo />
      <h1 className="h-display text-5xl text-bone">Page not found</h1>
      <p className="max-w-md text-mute">The page you are looking for does not exist or has moved.</p>
      <Link href="/dashboard" className="btn-gold">Go to the dashboard</Link>
    </main>
  );
}
