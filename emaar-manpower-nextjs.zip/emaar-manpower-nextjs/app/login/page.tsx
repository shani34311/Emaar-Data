import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getUser } from "@/lib/auth";
import Logo from "@/components/Logo";
import LoginForm from "./LoginForm";

export const metadata: Metadata = { title: "Sign in", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function LoginPage() {
  if (await getUser()) redirect("/dashboard");
  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-16">
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" />
      <div className="card relative w-full max-w-md p-8 sm:p-10">
        <div className="gold-rule absolute inset-x-0 top-0" />
        <Logo />
        <h1 className="h-display mt-8 text-3xl text-bone">Sign in</h1>
        <p className="mt-1 text-sm text-mute">EMAAR Manpower Dashboard (Areena)</p>
        <LoginForm />
      </div>
    </main>
  );
}
