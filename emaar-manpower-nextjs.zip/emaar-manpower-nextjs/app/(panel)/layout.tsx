import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { getSettings, getToday } from "@/lib/settings";
import { listForemen, listWorkers } from "@/lib/workers";
import { countWorkers } from "@/lib/stats";
import { ToastProvider } from "@/components/ui";
import { WorkerActionsProvider } from "@/components/WorkerActions";
import Shell, { type NavItem } from "@/components/Shell";

export const metadata: Metadata = { robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const [settings, today, workers, foremen] = await Promise.all([getSettings(), getToday(), listWorkers(), listForemen()]);
  const active = workers.filter((w) => !w.released_on);
  const c = countWorkers(active, today, settings.expiringDays);
  const positions = [...new Set(workers.map((w) => w.position))].sort((a, b) => a.localeCompare(b));

  const links: NavItem[] = [
    { href: "/dashboard", label: "Dashboard", icon: "◧", badge: c.expired + c.soon, tone: c.expired > 0 ? "bad" : "warn" },
    { href: "/workers", label: "Workers", icon: "☰", badge: active.length },
    { href: "/foremen", label: "Foremen", icon: "▦" },
    { href: "/released", label: "Released", icon: "↪", badge: workers.length - active.length },
  ];
  const adminLinks: NavItem[] =
    user.role === "admin"
      ? [
          { href: "/admin/users", label: "Users", icon: "◉" },
          { href: "/admin/activity", label: "Activity log", icon: "◷" },
          { href: "/admin/backup", label: "Backup & import", icon: "⇅" },
          { href: "/admin/settings", label: "Settings", icon: "⚙" },
        ]
      : [];

  return (
    <ToastProvider>
      <WorkerActionsProvider role={user.role} today={today} windowDays={settings.expiringDays} foremen={foremen.map((f) => f.name)} positions={positions}>
        <Shell title={settings.siteTitle} user={{ name: user.name, email: user.email, role: user.role }} links={links} adminLinks={adminLinks}>
          {children}
        </Shell>
      </WorkerActionsProvider>
    </ToastProvider>
  );
}
