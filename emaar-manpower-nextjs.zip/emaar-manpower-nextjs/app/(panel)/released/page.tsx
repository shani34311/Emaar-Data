import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { getSettings, getToday } from "@/lib/settings";
import { listWorkers } from "@/lib/workers";
import ReleasedManager from "./ReleasedManager";

export const metadata: Metadata = { title: "Released workers" };
export const dynamic = "force-dynamic";

export default async function ReleasedPage() {
  await requireUser();
  const [settings, today, all] = await Promise.all([getSettings(), getToday(), listWorkers()]);
  const released = all.filter((w) => w.released_on).sort((a, b) => ((a.released_on ?? "") < (b.released_on ?? "") ? 1 : -1));
  return <ReleasedManager workers={released} today={today} windowDays={settings.expiringDays} />;
}
