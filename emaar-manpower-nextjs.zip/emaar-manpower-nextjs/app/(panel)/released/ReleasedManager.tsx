"use client";
import { useMemo, useState } from "react";
import { NameButton, WorkerButtons } from "@/components/WorkerActions";
import { PageTitle, useToast } from "@/components/ui";
import { exportWorkersCsv } from "@/components/export";
import { fmtDate } from "@/lib/time";
import type { Worker } from "@/lib/types";

export default function ReleasedManager({ workers, today, windowDays }: { workers: Worker[]; today: string; windowDays: number }) {
  const toast = useToast();
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const n = q.trim().toLowerCase();
    return workers.filter((w) => !n || `${w.iqama} ${w.name} ${w.foreman} ${w.position} ${w.release_reason ?? ""}`.toLowerCase().includes(n));
  }, [workers, q]);
  return (
    <div>
      <PageTitle title={`Released workers (${workers.length})`} sub="Workers who left the work, with the release date and reason.">
        <input className="input !w-56 !py-2 text-sm" type="search" placeholder="Search" aria-label="Search released workers" value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn-ghost btn-sm" onClick={() => (workers.length ? exportWorkersCsv(list, `released-${today}.csv`, today, windowDays, true) : toast("Nothing to export.", "err"))}>Export CSV</button>
      </PageTitle>
      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead><tr><th className="th">Iqama No</th><th className="th">Name</th><th className="th">Position</th><th className="th">Foreman</th><th className="th">Shift</th><th className="th">Release date</th><th className="th">Reason</th><th className="th" /></tr></thead>
          <tbody>
            {list.map((w) => (
              <tr key={w.id} className="hover:bg-white/[0.03]">
                <td className="td tabular-nums">{w.iqama}</td>
                <td className="td"><NameButton w={w} /></td>
                <td className="td">{w.position}</td>
                <td className="td">{w.foreman}</td>
                <td className="td">{w.shift}</td>
                <td className="td tabular-nums">{fmtDate(w.released_on)}</td>
                <td className="!whitespace-normal td min-w-48">{w.release_reason}</td>
                <td className="td"><WorkerButtons w={w} released /></td>
              </tr>
            ))}
            {list.length === 0 && <tr><td className="td py-10 text-center text-mute" colSpan={8}>{workers.length ? "No matches." : "No released workers."}</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
