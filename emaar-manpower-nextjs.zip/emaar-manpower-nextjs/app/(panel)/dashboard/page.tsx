import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getSettings, getToday } from "@/lib/settings";
import { listForemen, listWorkers } from "@/lib/workers";
import { countWorkers, groupByForeman } from "@/lib/stats";
import { daysLeft, fmtDate, statusOf } from "@/lib/time";
import type { Worker } from "@/lib/types";
import { PageTitle } from "@/components/ui";
import { NameButton, WorkerButtons } from "@/components/WorkerActions";

export const metadata: Metadata = { title: "Dashboard" };
export const dynamic = "force-dynamic";

const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function Donut({ valid, soon, expired }: { valid: number; soon: number; expired: number }) {
  const total = valid + soon + expired;
  const R = 52, C = 2 * Math.PI * R;
  let off = 0;
  const segs = ([["stroke-bull", valid], ["stroke-warn", soon], ["stroke-bear", expired]] as const)
    .filter(([, n]) => n > 0)
    .map(([cls, n]) => {
      const len = (C * n) / total;
      const el = <circle key={cls} className={cls} cx="70" cy="70" r={R} fill="none" strokeWidth="16" strokeDasharray={`${len.toFixed(2)} ${(C - len).toFixed(2)}`} strokeDashoffset={(-off).toFixed(2)} />;
      off += len;
      return el;
    });
  return (
    <svg viewBox="0 0 140 140" className="mx-auto h-40 w-40" role="img" aria-label={`${valid} valid, ${soon} expiring soon, ${expired} expired`}>
      <g transform="rotate(-90 70 70)">
        <circle cx="70" cy="70" r={R} fill="none" strokeWidth="16" className="stroke-white/10" />
        {segs}
      </g>
      <text x="70" y="73" textAnchor="middle" className="fill-bone text-[28px] font-bold">{total}</text>
      <text x="70" y="90" textAnchor="middle" className="fill-mute text-[10px]">active</text>
    </svg>
  );
}

function MonthBars({ workers, today }: { workers: Worker[]; today: string }) {
  const p = today.split("-");
  let y = +p[0], m = +p[1];
  const items: { l: string; v: number; bad?: boolean }[] = [{ l: "Expired", v: workers.filter((w) => daysLeft(w.expiry, today) < 0).length, bad: true }];
  for (let i = 0; i < 6; i++) {
    const key = `${y}-${String(m).padStart(2, "0")}`;
    items.push({ l: `${MON[m - 1]} '${String(y).slice(2)}`, v: workers.filter((w) => w.expiry.slice(0, 7) === key && daysLeft(w.expiry, today) >= 0).length });
    m++; if (m > 12) { m = 1; y++; }
  }
  const max = Math.max(1, ...items.map((i) => i.v));
  return (
    <div className="flex h-44 items-end gap-2 pt-2 sm:gap-3">
      {items.map((i) => (
        <div key={i.l} className="flex h-full flex-1 flex-col items-center justify-end gap-1 text-[11px] text-mute sm:text-xs">
          <span className="font-bold tabular-nums text-bone">{i.v}</span>
          <div className={`w-full max-w-14 rounded-t ${i.bad ? "bg-bear" : "bg-gold"}`} style={{ height: `${Math.round((i.v / max) * 108)}px` }} />
          <span className="whitespace-nowrap">{i.l}</span>
        </div>
      ))}
    </div>
  );
}

function Attention({ title, list, today, tone, status }: { title: string; list: Worker[]; today: string; tone: "bear" | "warn"; status: string }) {
  return (
    <section className="card p-5">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h2 className="h-display text-xl text-bone">{title} <span className={tone === "bear" ? "text-bear" : "text-warn"}>({list.length})</span></h2>
        {list.length > 8 && <Link href={`/workers?status=${status}`} className="btn-ghost btn-xs">View all {list.length}</Link>}
      </div>
      {list.length === 0 ? <p className="py-6 text-center text-sm text-mute">Nothing here. All good.</p> : (
        <ul className="divide-y divide-line/60">
          {list.slice(0, 8).map((w) => {
            const d = daysLeft(w.expiry, today);
            return (
              <li key={w.id} className="flex items-start justify-between gap-3 py-3">
                <div className="min-w-0">
                  <NameButton w={w} />
                  <p className="truncate text-xs text-mute">{w.position} · {w.foreman} · {w.iqama}</p>
                </div>
                <div className="shrink-0 text-right">
                  <span className={`inline-block rounded-full px-2.5 py-0.5 text-[11px] font-bold ring-1 ${tone === "bear" ? "bg-bear/15 text-bear ring-bear/40" : "bg-warn/15 text-warn ring-warn/40"}`}>
                    {d < 0 ? `${Math.abs(d)} days ago` : d === 0 ? "Today" : `${d} days`}
                  </span>
                  <p className="mt-0.5 text-xs text-mute">{fmtDate(w.expiry)}</p>
                  <div className="mt-1.5"><WorkerButtons w={w} /></div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

export default async function DashboardPage() {
  await requireUser();
  const [settings, today, all, foremen] = await Promise.all([getSettings(), getToday(), listWorkers(), listForemen()]);
  const active = all.filter((w) => !w.released_on);
  const win = settings.expiringDays;
  const c = countWorkers(active, today, win);
  const expired = active.filter((w) => statusOf(w.expiry, today, win) === "expired");
  const soon = active.filter((w) => statusOf(w.expiry, today, win) === "soon");
  const groups = groupByForeman(active, foremen).filter((g) => g.workers.length);
  const pct = (n: number) => (c.total ? `${Math.round((n / c.total) * 100)}% of active` : "");

  const tiles = [
    { href: "/workers", n: c.total, label: "Active workers", sub: `Day ${c.day} · Night ${c.night}`, bar: "bg-mute", text: "text-bone" },
    { href: "/workers?status=valid", n: c.valid, label: "Valid iqama", sub: pct(c.valid), bar: "bg-bull", text: "text-bull" },
    { href: "/workers?status=soon", n: c.soon, label: `Expiring in ${win} days`, sub: pct(c.soon), bar: "bg-warn", text: "text-warn" },
    { href: "/workers?status=expired", n: c.expired, label: "Expired (invalid)", sub: pct(c.expired), bar: "bg-bear", text: "text-bear" },
  ];

  return (
    <div className="space-y-6">
      <PageTitle title="Dashboard" sub={`Today is ${fmtDate(today)}. Click a box to see those workers.`} />
      <div className="grid overflow-hidden rounded-2xl border border-line bg-card sm:grid-cols-2 lg:grid-cols-4">
        {tiles.map((t) => (
          <Link key={t.href} href={t.href} className="group relative border-b border-line p-5 transition hover:bg-white/[0.03] sm:border-r lg:border-b-0 lg:last:border-r-0">
            <span className={`absolute inset-x-0 top-0 h-1 ${t.bar}`} />
            <p className={`h-display text-5xl tabular-nums ${t.text}`}>{t.n}</p>
            <p className="mt-2 text-sm font-semibold text-bone">{t.label}</p>
            <p className="text-xs text-mute">{t.sub}</p>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <section className="card p-5">
          <h2 className="h-display mb-3 text-xl text-bone">Iqama status</h2>
          <Donut valid={c.valid} soon={c.soon} expired={c.expired} />
          <ul className="mt-4 space-y-1.5 text-sm">
            <li className="flex justify-between"><span><i className="mr-2 inline-block h-2.5 w-2.5 rounded-full bg-bull" />Valid</span><b>{c.valid}</b></li>
            <li className="flex justify-between"><span><i className="mr-2 inline-block h-2.5 w-2.5 rounded-full bg-warn" />Expiring soon</span><b>{c.soon}</b></li>
            <li className="flex justify-between"><span><i className="mr-2 inline-block h-2.5 w-2.5 rounded-full bg-bear" />Expired</span><b>{c.expired}</b></li>
          </ul>
        </section>
        <section className="card p-5">
          <h2 className="h-display mb-1 text-xl text-bone">Iqama expiries by month</h2>
          <MonthBars workers={active} today={today} />
          <p className="mt-3 text-xs text-dim">Active workers whose iqama expires in each month. The red bar is already expired.</p>
        </section>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Attention title="Expired iqama" list={expired} today={today} tone="bear" status="expired" />
        <Attention title={`Expiring in ${win} days`} list={soon} today={today} tone="warn" status="soon" />
      </div>

      <section className="card p-5">
        <h2 className="h-display mb-4 text-xl text-bone">Workers by foreman</h2>
        {groups.length === 0 ? (
          <p className="py-6 text-center text-sm text-mute">No workers yet. Open <Link href="/workers" className="text-gold underline">Workers</Link> and add the first one.</p>
        ) : (
          <div className="space-y-3">
            {groups.map((g) => {
              const k = countWorkers(g.workers, today, win);
              return (
                <Link key={g.id} href={`/foremen#f-${g.id}`} className="grid items-center gap-2 rounded-lg px-2 py-1.5 text-sm transition hover:bg-white/[0.04] sm:grid-cols-[minmax(120px,1fr)_3fr_auto] sm:gap-4">
                  <span className="truncate font-semibold text-bone">{g.name}</span>
                  <span className="flex h-3.5 overflow-hidden rounded bg-white/10" aria-hidden="true">
                    <i className="bg-bull" style={{ width: `${(k.valid / k.total) * 100}%` }} />
                    <i className="bg-warn" style={{ width: `${(k.soon / k.total) * 100}%` }} />
                    <i className="bg-bear" style={{ width: `${(k.expired / k.total) * 100}%` }} />
                  </span>
                  <span className="whitespace-nowrap text-xs tabular-nums text-mute">{k.total} workers · {k.valid} / {k.soon} / {k.expired}</span>
                </Link>
              );
            })}
            <p className="text-xs text-dim">Numbers show valid / expiring soon / expired.</p>
          </div>
        )}
      </section>
    </div>
  );
}
