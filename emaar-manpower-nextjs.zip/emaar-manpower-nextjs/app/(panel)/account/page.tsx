import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { ROLE_LABEL } from "@/lib/types";
import { PageTitle } from "@/components/ui";
import PasswordForm from "./PasswordForm";

export const metadata: Metadata = { title: "My account" };
export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const u = await requireUser();
  return (
    <div className="max-w-xl space-y-6">
      <PageTitle title="My account" />
      <section className="card p-6">
        <dl className="grid gap-2 text-sm sm:grid-cols-[110px_1fr]">
          <dt className="text-mute">Name</dt><dd className="font-semibold text-bone">{u.name}</dd>
          <dt className="text-mute">Email</dt><dd className="font-semibold text-bone">{u.email}</dd>
          <dt className="text-mute">Role</dt><dd className="font-semibold text-bone">{ROLE_LABEL[u.role]}</dd>
        </dl>
      </section>
      <PasswordForm />
    </div>
  );
}
