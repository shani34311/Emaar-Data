"use client";
import { useState } from "react";
import { ErrorLine, Field, api, useToast } from "@/components/ui";

export default function PasswordForm() {
  const toast = useToast();
  const [cur, setCur] = useState("");
  const [n1, setN1] = useState("");
  const [n2, setN2] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    if (n1 !== n2) return setErr("The two new passwords do not match.");
    setBusy(true);
    try {
      await api("/api/password", "POST", { current: cur, next: n1 });
      toast("Password changed.");
      setCur(""); setN1(""); setN2("");
    } catch (x) {
      setErr((x as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit} className="card space-y-4 p-6">
      <h2 className="h-display text-xl text-bone">Change password</h2>
      <Field label="Current password"><input className="input" type="password" autoComplete="current-password" required value={cur} onChange={(e) => setCur(e.target.value)} /></Field>
      <Field label="New password" hint="At least 10 characters."><input className="input" type="password" autoComplete="new-password" minLength={10} required value={n1} onChange={(e) => setN1(e.target.value)} /></Field>
      <Field label="Repeat new password"><input className="input" type="password" autoComplete="new-password" minLength={10} required value={n2} onChange={(e) => setN2(e.target.value)} /></Field>
      <ErrorLine text={err} />
      <button className="btn-gold" disabled={busy}>{busy ? "Saving…" : "Change password"}</button>
    </form>
  );
}
