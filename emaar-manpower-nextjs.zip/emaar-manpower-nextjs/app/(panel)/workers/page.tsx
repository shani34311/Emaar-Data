import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { getSettings, getToday } from "@/lib/settings";
import { listForemen, listWorkers } from "@/lib/workers";
import WorkersManager from "./WorkersManager";

export const metadata: Metadata = { title: "Workers" };
export const dynamic = "force-dynamic";

export default async function WorkersPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  await requireUser();
  const sp = await searchParams;
  const [settings, today, all, foremen] = await Promise.all([getSettings(), getToday(), listWorkers(), listForemen()]);
  const initial = ["valid", "soon", "expired"].includes(sp.status ?? "") ? (sp.status as string) : "all";
  return <WorkersManager workers={all.filter((w) => !w.released_on)} foremen={foremen} today={today} windowDays={settings.expiringDays} title={settings.siteTitle} initialStatus={initial} />;
}
