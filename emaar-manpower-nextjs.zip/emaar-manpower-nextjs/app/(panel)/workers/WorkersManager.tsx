"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { NameButton, WorkerButtons, useWorkerActions } from "@/components/WorkerActions";
import { StatusTag } from "@/components/bits";
import { PageTitle, useToast } from "@/components/ui";
import PrintSheet from "@/components/PrintSheet";
import { exportWorkersCsv, exportWorkersPdf } from "@/components/export";
import { daysLeft, fmtDate, statusOf } from "@/lib/time";
import { ROLE_RANK, type Foreman, type Worker } from "@/lib/types";

type SortKey = "iqama" | "name" | "position" | "foreman" | "shift" | "expiry";
const COLS: [SortKey, string][] = [["iqama", "Iqama No"], ["name", "Name"], ["position", "Position"], ["foreman", "Foreman"], ["shift", "Shift"], ["expiry", "Expiry"]];

export default function WorkersManager({ workers, foremen, today, windowDays, title, initialStatus }: {
  workers: Worker[]; foremen: Foreman[]; today: string; windowDays: number; title: string; initialStatus: string;
}) {
  const a = useWorkerActions();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState(initialStatus);
  const [shift, setShift] = useState("");
  const [foreman, setForeman] = useState("");
  const [sort, setSort] = useState<SortKey>("expiry");
  const [dir, setDir] = useState(1);
  const [printing, setPrinting] = useState(false);
  useEffect(() => setStatus(initialStatus), [initialStatus]);

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    const out = workers.filter((w) => {
      if (status !== "all" && statusOf(w.expiry, today, windowDays) !== status) return false;
      if (shift && w.shift !== shift) return false;
      if (foreman && w.foreman_id !== foreman) return false;
      return !needle || `${w.iqama} ${w.name} ${w.foreman} ${w.position} ${w.nationality} ${w.mobile}`.toLowerCase().includes(needle);
    });
    out.sort((x, y) => {
      const p = String(x[sort]).toLowerCase(), r = String(y[sort]).toLowerCase();
      return p < r ? -dir : p > r ? dir : x.name.localeCompare(y.name);
    });
    return out;
  }, [workers, q, status, shift, foreman, sort, dir, today, windowDays]);

  const clear = () => { setQ(""); setStatus("all"); setShift(""); setForeman(""); setSort("expiry"); setDir(1); };
  const donePrint = useCallback(() => setPrinting(false), []);
  const canAdd = ROLE_RANK[a.role] >= ROLE_RANK.manager;
  const none = () => toast("No workers to export.", "err");

  return (
    <div>
      <PageTitle title="Workers" sub="Search, filter and manage everyone who is currently active.">
        {canAdd && <button className="btn-gold btn-sm" onClick={a.add}>Add worker</button>}
        <button className="btn-ghost btn-sm" onClick={() => (list.length ? exportWorkersCsv(list, `workers-${today}.csv`, today, windowDays) : none())}>Export CSV</button>
        <button className="btn-ghost btn-sm" onClick={() => (list.length ? exportWorkersPdf(list, title, today, windowDays).catch(() => toast("Could not create the PDF. Use Print and choose “Save as PDF”.", "err")) : none())}>Save as PDF</button>
        <button className="btn-ghost btn-sm" onClick={() => (list.length ? setPrinting(true) : none())}>Print list</button>
      </PageTitle>

      <div className="no-print mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_1fr_auto]">
        <input className="input sm:col-span-2 lg:col-span-1" type="search" placeholder="Search name, iqama, position, foreman" aria-label="Search" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input" aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="all">All statuses</option><option value="valid">Valid</option><option value="soon">Expiring soon</option><option value="expired">Expired</option>
        </select>
        <select className="input" aria-label="Shift" value={shift} onChange={(e) => setShift(e.target.value)}>
          <option value="">All shifts</option><option>Day shift</option><option>Night shift</option>
        </select>
        <select className="input" aria-label="Foreman" value={foreman} onChange={(e) => setForeman(e.target.value)}>
          <option value="">All foremen</option>{foremen.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
        </select>
        <button className="btn-ghost" onClick={clear}>Clear</button>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr>
              {COLS.map(([k, label]) => (
                <th key={k} className="th" aria-sort={sort === k ? (dir > 0 ? "ascending" : "descending") : "none"}>
                  <button onClick={() => (sort === k ? setDir(-dir) : (setSort(k), setDir(1)))} className="uppercase tracking-wider hover:text-bone">{label}{sort === k ? (dir > 0 ? " ▲" : " ▼") : ""}</button>
                </th>
              ))}
              <th className="th">Days left</th><th className="th">Status</th><th className="th" />
            </tr>
          </thead>
          <tbody>
            {list.map((w) => (
              <tr key={w.id} className="hover:bg-white/[0.03]">
                <td className="td tabular-nums">{w.iqama}</td>
                <td className="td"><NameButton w={w} /></td>
                <td className="td">{w.position}</td>
                <td className="td">{w.foreman}</td>
                <td className="td">{w.shift}</td>
                <td className="td tabular-nums">{fmtDate(w.expiry)}</td>
                <td className="td tabular-nums">{daysLeft(w.expiry, today)}</td>
                <td className="td"><StatusTag status={statusOf(w.expiry, today, windowDays)} /></td>
                <td className="td"><WorkerButtons w={w} /></td>
              </tr>
            ))}
            {list.length === 0 && (
              <tr><td className="td py-10 text-center text-mute" colSpan={9}>{workers.length ? "No workers match these filters." : "No workers yet. Click “Add worker” to start."}</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="no-print mt-3 text-xs text-mute">Showing {list.length} of {workers.length} active workers</p>

      {printing && <PrintSheet title={title} groups={[{ heading: "Workers list", workers: list }]} today={today} windowDays={windowDays} withForeman onDone={donePrint} />}
    </div>
  );
}
