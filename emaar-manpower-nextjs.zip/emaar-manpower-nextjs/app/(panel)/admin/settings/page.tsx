import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { PageTitle } from "@/components/ui";
import SettingsForm from "./SettingsForm";

export const metadata: Metadata = { title: "Settings" };
export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  await requireUser("admin");
  return (
    <div className="max-w-xl">
      <PageTitle title="Settings" />
      <SettingsForm initial={await getSettings()} />
    </div>
  );
}
