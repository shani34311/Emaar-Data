"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ErrorLine, Field, api, useToast } from "@/components/ui";
import { TIMEZONES, type Settings } from "@/lib/types";

export default function SettingsForm({ initial }: { initial: Settings }) {
  const router = useRouter();
  const toast = useToast();
  const [s, setS] = useState({ ...initial, expiringDays: String(initial.expiringDays) });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr(null);
    try {
      await api("/api/admin/settings", "POST", { siteTitle: s.siteTitle, expiringDays: Number(s.expiringDays), timezone: s.timezone });
      toast("Settings saved.");
      router.refresh();
    } catch (x) {
      setErr((x as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit} className="card space-y-5 p-6">
      <Field label="Site title" hint="Shown at the top of every page and on printed sheets."><input className="input" required minLength={3} maxLength={80} value={s.siteTitle} onChange={(e) => setS({ ...s, siteTitle: e.target.value })} /></Field>
      <Field label="Expiring-soon window (days)" hint="An iqama counts as “expiring soon” when it expires within this many days from today. Default is 30."><input className="input" type="number" min={1} max={180} required value={s.expiringDays} onChange={(e) => setS({ ...s, expiringDays: e.target.value })} /></Field>
      <Field label="Time zone" hint="Decides what “today” is when working out how many days are left.">
        <select className="input" value={s.timezone} onChange={(e) => setS({ ...s, timezone: e.target.value })}>{TIMEZONES.map((t) => <option key={t}>{t}</option>)}</select>
      </Field>
      <ErrorLine text={err} />
      <button className="btn-gold" disabled={busy}>{busy ? "Saving…" : "Save settings"}</button>
    </form>
  );
}
