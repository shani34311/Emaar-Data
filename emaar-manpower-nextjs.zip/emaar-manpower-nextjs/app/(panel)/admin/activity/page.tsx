import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { q } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { PageTitle } from "@/components/ui";
import ActivityTable from "./ActivityTable";

export const metadata: Metadata = { title: "Activity log" };
export const dynamic = "force-dynamic";

export default async function ActivityPage() {
  await requireUser("admin");
  const [s, rows] = await Promise.all([
    getSettings(),
    q<{ id: string; at: string; user_email: string; action: string; detail: string }>("SELECT id::text, at::text AS at, user_email, action, detail FROM activity ORDER BY id DESC LIMIT 500"),
  ]);
  return (
    <div>
      <PageTitle title="Activity log" sub="The latest 500 actions: who did what, and when." />
      <ActivityTable rows={rows} tz={s.timezone} />
    </div>
  );
}
