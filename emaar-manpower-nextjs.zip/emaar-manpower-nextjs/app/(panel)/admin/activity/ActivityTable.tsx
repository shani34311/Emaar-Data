"use client";
import { useMemo, useState } from "react";
import { fmtDateTime } from "@/lib/time";

type Row = { id: string; at: string; user_email: string; action: string; detail: string };

export default function ActivityTable({ rows, tz }: { rows: Row[]; tz: string }) {
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const n = q.trim().toLowerCase();
    return rows.filter((r) => !n || `${r.user_email} ${r.action} ${r.detail}`.toLowerCase().includes(n));
  }, [rows, q]);
  return (
    <div className="space-y-3">
      <input className="input max-w-sm" type="search" placeholder="Search the log" aria-label="Search the log" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead><tr><th className="th">When</th><th className="th">User</th><th className="th">Action</th><th className="th">Details</th></tr></thead>
          <tbody>
            {list.map((r) => (
              <tr key={r.id} className="hover:bg-white/[0.03]">
                <td className="td tabular-nums text-mute">{fmtDateTime(r.at, tz)}</td>
                <td className="td">{r.user_email}</td>
                <td className="td font-semibold">{r.action}</td>
                <td className="!whitespace-normal td min-w-64 text-mute">{r.detail}</td>
              </tr>
            ))}
            {list.length === 0 && <tr><td className="td py-10 text-center text-mute" colSpan={4}>Nothing found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
