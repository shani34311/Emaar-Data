"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ErrorLine, api, useToast } from "@/components/ui";
import { csvFile, parseCsv } from "@/components/export";

type Result = { added: number; skipped: number; invalid: number; errors: string[] };

const KEYS: Record<string, string> = {
  iqamano: "iqama", iqama: "iqama", name: "name", position: "position", expiry: "expiry", expirydate: "expiry", iqamaexpiry: "expiry", iqamaexpirydate: "expiry",
  shift: "shift", foreman: "foreman", foremanname: "foreman", nationality: "nationality", mobile: "mobile", phone: "mobile", remarks: "remarks", notes: "remarks",
};
const pad = (n: number) => String(n).padStart(2, "0");
function normDate(s: string) {
  const t = s.trim();
  const m = /^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/.exec(t);
  return m ? `${m[3]}-${pad(+m[2])}-${pad(+m[1])}` : t.slice(0, 10);
}

export default function BackupManager({ active, released }: { active: number; released: number }) {
  const router = useRouter();
  const toast = useToast();
  const [recs, setRecs] = useState<unknown[] | null>(null);
  const [name, setName] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [res, setRes] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);

  function template() {
    csvFile("workers-template.csv", [
      ["Iqama No", "Name", "Position", "Expiry", "Shift", "Foreman", "Nationality", "Mobile", "Remarks"],
      ["2123456789", "Example Worker", "Electrician", "2027-05-31", "Day shift", "Foreman Name", "Pakistan", "0500000000", ""],
    ]);
  }

  async function pick(file: File | undefined) {
    setErr(null); setRes(null); setRecs(null);
    if (!file) return;
    try {
      const text = await file.text();
      let out: unknown[];
      if (/\.json$/i.test(file.name)) {
        const j = JSON.parse(text);
        out = Array.isArray(j) ? j : j.workers;
        if (!Array.isArray(out)) throw new Error("This JSON file has no workers list.");
      } else {
        const rows = parseCsv(text);
        if (rows.length < 2) throw new Error("The CSV file has no data rows.");
        const map = rows[0].map((h) => KEYS[h.toLowerCase().replace(/[^a-z]/g, "")] ?? null);
        if (!map.includes("iqama") || !map.includes("name")) throw new Error("The first row must contain column names like: Iqama No, Name, Position, Expiry, Shift, Foreman.");
        out = rows.slice(1).map((r) => {
          const o: Record<string, string> = {};
          map.forEach((k, i) => { if (k) o[k] = (r[i] ?? "").trim(); });
          o.expiry = normDate(o.expiry ?? "");
          o.shift = /night/i.test(o.shift ?? "") ? "Night shift" : "Day shift";
          return o;
        });
      }
      setRecs(out); setName(file.name);
    } catch (e) {
      setErr((e as Error).message);
    }
  }

  async function go() {
    if (!recs) return;
    setBusy(true); setErr(null);
    try {
      const r = await api<Result>("/api/admin/import", "POST", { records: recs });
      setRes(r); setRecs(null);
      toast(`Import finished: ${r.added} added.`);
      router.refresh();
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <section className="card space-y-3 p-6">
        <h2 className="h-display text-xl text-bone">Backup</h2>
        <p className="text-sm text-mute">Download everything (workers, released workers and iqama update history) as one file. Keep a copy somewhere safe, for example once a week. Now: {active} active and {released} released workers.</p>
        <a href="/api/admin/export" className="btn-gold btn-sm">Download backup file</a>
      </section>

      <section className="card space-y-4 p-6">
        <h2 className="h-display text-xl text-bone">Import workers</h2>
        <p className="text-sm leading-6 text-mute">
          Add many workers at once from a <b className="text-bone">CSV file</b> (in Excel: Save As → CSV), or restore from a <b className="text-bone">backup (.json)</b> file, including the backup from the earlier single-page dashboard.
          Workers whose iqama is already active are skipped, so nothing is overwritten and importing twice is safe.
        </p>
        <div><button className="btn-ghost btn-sm" onClick={template}>Download CSV template</button></div>
        <label className="block rounded-xl border-2 border-dashed border-line-strong p-4">
          <span className="label">Choose a .csv or .json file</span>
          <input type="file" accept=".csv,.json,text/csv,application/json" className="block w-full text-sm text-mute file:mr-3 file:rounded-full file:border-0 file:bg-gold file:px-4 file:py-2 file:text-xs file:font-bold file:text-ink" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} />
        </label>
        <ErrorLine text={err} />
        {recs && (
          <p className="flex flex-wrap items-center gap-3 text-sm text-bone">
            Found <b>{recs.length}</b> records in {name}.
            <button className="btn-gold btn-sm" onClick={go} disabled={busy}>{busy ? "Importing…" : "Import now"}</button>
          </p>
        )}
        {res && (
          <div className="rounded-xl border border-line bg-ink-2 p-4 text-sm" role="status">
            <p className="font-semibold text-bone">Import finished. Added: {res.added} · Skipped (already there): {res.skipped} · Rows with errors: {res.invalid}</p>
            {res.errors.length > 0 && (
              <ul className="mt-2 list-disc space-y-0.5 pl-5 text-bear">{res.errors.map((e, i) => <li key={i}>{e}</li>)}</ul>
            )}
            {res.invalid > res.errors.length && <p className="mt-2 text-xs text-dim">Showing the first {res.errors.length} errors.</p>}
          </div>
        )}
      </section>
    </div>
  );
}
