import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { listWorkers } from "@/lib/workers";
import { PageTitle } from "@/components/ui";
import BackupManager from "./BackupManager";

export const metadata: Metadata = { title: "Backup & import" };
export const dynamic = "force-dynamic";

export default async function BackupPage() {
  await requireUser("admin");
  const all = await listWorkers();
  return (
    <div className="max-w-3xl">
      <PageTitle title="Backup & import" />
      <BackupManager active={all.filter((w) => !w.released_on).length} released={all.filter((w) => w.released_on).length} />
    </div>
  );
}
