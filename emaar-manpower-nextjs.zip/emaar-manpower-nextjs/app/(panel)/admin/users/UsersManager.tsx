"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ErrorLine, Field, Modal, api, useToast } from "@/components/ui";
import { fmtDateTime } from "@/lib/time";
import { ROLE_LABEL, type AppUser, type Role } from "@/lib/types";

type Form = { id?: string; email: string; name: string; role: Role; active: boolean; password: string };
const EMPTY: Form = { email: "", name: "", role: "viewer", active: true, password: "" };

export default function UsersManager({ users, meId }: { users: AppUser[]; meId: string }) {
  const router = useRouter();
  const toast = useToast();
  const [f, setF] = useState<Form | null>(null);
  const [del, setDel] = useState<AppUser | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function run(fn: () => Promise<unknown>, ok: string, done: () => void) {
    setBusy(true); setErr(null);
    try { await fn(); toast(ok); done(); router.refresh(); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end"><button className="btn-gold btn-sm" onClick={() => { setF({ ...EMPTY }); setErr(null); }}>Add user</button></div>
      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead><tr><th className="th">Name</th><th className="th">Email</th><th className="th">Role</th><th className="th">Status</th><th className="th">Last sign-in</th><th className="th" /></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="hover:bg-white/[0.03]">
                <td className="td font-semibold">{u.name}</td>
                <td className="td">{u.email}</td>
                <td className="td">{ROLE_LABEL[u.role]}</td>
                <td className="td">{u.active ? <span className="rounded-full bg-bull/15 px-2.5 py-0.5 text-[11px] font-bold text-bull ring-1 ring-bull/40">Active</span> : <span className="rounded-full bg-white/10 px-2.5 py-0.5 text-[11px] font-bold text-mute ring-1 ring-white/20">Disabled</span>}</td>
                <td className="td text-mute">{fmtDateTime(u.last_login)}</td>
                <td className="td">
                  <span className="inline-flex gap-1.5">
                    <button className="btn-ghost btn-xs" onClick={() => { setF({ id: u.id, email: u.email, name: u.name, role: u.role, active: u.active, password: "" }); setErr(null); }}>Edit</button>
                    {u.id !== meId && <button className="btn-danger btn-xs" onClick={() => { setDel(u); setErr(null); }}>Delete</button>}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-dim"><b className="text-mute">Administrator</b>: everything, including this admin panel. <b className="text-mute">Manager</b>: add, edit, update iqama, release and restore workers. <b className="text-mute">Viewer</b>: can only look and print. Keep at least two administrators.</p>

      <Modal open={!!f} onClose={() => setF(null)} title={f?.id ? "Edit user" : "Add user"}>
        {f && (
          <form className="grid gap-4" onSubmit={(e) => { e.preventDefault(); run(() => (f.id ? api(`/api/admin/users/${f.id}`, "PATCH", f) : api("/api/admin/users", "POST", f)), f.id ? "User saved." : "User created.", () => setF(null)); }}>
            <Field label="Full name"><input className="input" required maxLength={60} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoFocus /></Field>
            <Field label="Email (used to sign in)"><input className="input" type="email" required maxLength={120} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
            <Field label="Role">
              <select className="input" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })} disabled={f.id === meId}>
                {(["viewer", "manager", "admin"] as Role[]).map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
              </select>
            </Field>
            <Field label={f.id ? "New password (leave empty to keep)" : "Password"} hint="At least 10 characters.">
              <input className="input" type="password" autoComplete="new-password" minLength={10} required={!f.id} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
            </Field>
            <label className="flex items-center gap-2 text-sm text-bone"><input type="checkbox" checked={f.active} disabled={f.id === meId} onChange={(e) => setF({ ...f, active: e.target.checked })} /> Account is active</label>
            <ErrorLine text={err} />
            <div className="flex gap-2"><button className="btn-gold" disabled={busy}>{busy ? "Saving…" : "Save user"}</button><button type="button" className="btn-ghost" onClick={() => setF(null)}>Cancel</button></div>
          </form>
        )}
      </Modal>

      <Modal open={!!del} onClose={() => setDel(null)} title="Delete user">
        {del && (
          <div className="space-y-4">
            <p className="text-sm text-mute">Delete <b className="text-bone">{del.email}</b>? Disabling the account instead keeps it for the records.</p>
            <ErrorLine text={err} />
            <div className="flex gap-2"><button className="btn-danger" disabled={busy} onClick={() => run(() => api(`/api/admin/users/${del.id}`, "DELETE"), "User deleted.", () => setDel(null))}>{busy ? "Please wait…" : "Delete user"}</button><button className="btn-ghost" onClick={() => setDel(null)}>Cancel</button></div>
          </div>
        )}
      </Modal>
    </div>
  );
}
