import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { listUsers } from "@/lib/users";
import { PageTitle } from "@/components/ui";
import UsersManager from "./UsersManager";

export const metadata: Metadata = { title: "Users" };
export const dynamic = "force-dynamic";

export default async function UsersPage() {
  const me = await requireUser("admin");
  const users = await listUsers();
  return (
    <div>
      <PageTitle title="Users" sub="Who can sign in, and what they are allowed to do." />
      <UsersManager users={users} meId={me.id} />
    </div>
  );
}
