"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { NameButton, WorkerButtons, useWorkerActions } from "@/components/WorkerActions";
import { StatusTag } from "@/components/bits";
import { ErrorLine, Field, Modal, PageTitle, api, useToast } from "@/components/ui";
import PrintSheet, { type PrintGroup } from "@/components/PrintSheet";
import { countWorkers, groupByForeman } from "@/lib/stats";
import { daysLeft, fmtDate, statusOf } from "@/lib/time";
import { ROLE_RANK, type Foreman, type Worker } from "@/lib/types";

export default function ForemenManager({ workers, foremen, records, today, windowDays, title }: {
  workers: Worker[]; foremen: Foreman[]; records: Record<string, number>; today: string; windowDays: number; title: string;
}) {
  const a = useWorkerActions();
  const router = useRouter();
  const toast = useToast();
  const groups = useMemo(() => groupByForeman(workers, foremen), [workers, foremen]);
  const [shut, setShut] = useState<Record<string, boolean>>({});
  const [job, setJob] = useState<PrintGroup[] | null>(null);
  const [edit, setEdit] = useState<{ id: string; name: string; mode: "rename" | "delete" } | null>(null);
  const [val, setVal] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const manager = ROLE_RANK[a.role] >= ROLE_RANK.manager;
  const admin = a.role === "admin";
  const donePrint = useCallback(() => setJob(null), []);

  useEffect(() => {
    const id = window.location.hash.slice(1);
    if (id) document.getElementById(id)?.scrollIntoView({ block: "start" });
  }, []);

  const heading = (g: { name: string }) => `Foreman: ${g.name}`;
  const printOne = (g: (typeof groups)[number]) => setJob([{ heading: heading(g), workers: g.workers, signature: true }]);
  const printAll = () => {
    const g = groups.filter((x) => x.workers.length);
    if (!g.length) return toast("No workers to print.", "err");
    setJob(g.map((x) => ({ heading: heading(x), workers: x.workers, signature: true })));
  };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!edit) return;
    setBusy(true); setErr(null);
    try {
      if (edit.mode === "rename") await api(`/api/foremen/${edit.id}`, "PATCH", { name: val });
      else await api(`/api/foremen/${edit.id}`, "DELETE");
      toast(edit.mode === "rename" ? "Foreman renamed." : "Foreman deleted.");
      setEdit(null);
      router.refresh();
    } catch (x) {
      setErr((x as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const open = (g: { id: string; name: string }, mode: "rename" | "delete") => { setEdit({ id: g.id, name: g.name, mode }); setVal(g.name); setErr(null); };

  return (
    <div>
      <PageTitle title="Workers by foreman" sub="Each foreman’s active workers. Print a separate sheet for every foreman.">
        <button className="btn-ghost btn-sm" onClick={() => setShut({})}>Expand all</button>
        <button className="btn-ghost btn-sm" onClick={() => setShut(Object.fromEntries(groups.map((g) => [g.id, true])))}>Collapse all</button>
        <button className="btn-gold btn-sm" onClick={printAll}>Print all foremen</button>
      </PageTitle>

      {groups.length === 0 && <p className="card p-8 text-center text-mute">No foremen yet. They appear when you add workers.</p>}

      <div className="space-y-4">
        {groups.map((g) => {
          const k = countWorkers(g.workers, today, windowDays);
          const empty = g.workers.length === 0;
          const closed = shut[g.id];
          return (
            <section key={g.id} id={`f-${g.id}`} className="card scroll-mt-24 overflow-hidden">
              <div className={`flex flex-wrap items-center justify-between gap-3 bg-ink-2 px-4 py-3 ${closed || empty ? "" : "border-b border-line"}`}>
                <div>
                  <h2 className="h-display text-xl text-bone">{g.name}</h2>
                  <div className="mt-1.5 flex flex-wrap gap-1.5 text-[11px] font-semibold">
                    <span className="chip">{k.total} {k.total === 1 ? "worker" : "workers"}</span>
                    <span className="chip !border-bull/40 !text-bull">{k.valid} valid</span>
                    <span className="chip !border-warn/40 !text-warn">{k.soon} expiring</span>
                    <span className="chip !border-bear/40 !text-bear">{k.expired} expired</span>
                    <span className="chip">Day {k.day} / Night {k.night}</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {!empty && <button className="btn-ghost btn-xs" onClick={() => setShut({ ...shut, [g.id]: !closed })}>{closed ? "Show workers" : "Hide workers"}</button>}
                  {!empty && <button className="btn-gold btn-xs" onClick={() => printOne(g)}>Print</button>}
                  {manager && <button className="btn-ghost btn-xs" onClick={() => open(g, "rename")}>Rename</button>}
                  {admin && !records[g.id] && <button className="btn-danger btn-xs" onClick={() => open(g, "delete")}>Delete</button>}
                </div>
              </div>
              {empty && <p className="px-4 py-5 text-sm text-mute">No active workers under this foreman.</p>}
              {!empty && !closed && (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead><tr><th className="th">Iqama No</th><th className="th">Name</th><th className="th">Position</th><th className="th">Expiry</th><th className="th">Days left</th><th className="th">Status</th><th className="th">Shift</th><th className="th" /></tr></thead>
                    <tbody>
                      {g.workers.map((w) => (
                        <tr key={w.id} className="hover:bg-white/[0.03]">
                          <td className="td tabular-nums">{w.iqama}</td>
                          <td className="td"><NameButton w={w} /></td>
                          <td className="td">{w.position}</td>
                          <td className="td tabular-nums">{fmtDate(w.expiry)}</td>
                          <td className="td tabular-nums">{daysLeft(w.expiry, today)}</td>
                          <td className="td"><StatusTag status={statusOf(w.expiry, today, windowDays)} /></td>
                          <td className="td">{w.shift}</td>
                          <td className="td"><WorkerButtons w={w} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          );
        })}
      </div>

      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.mode === "delete" ? "Delete foreman" : "Rename foreman"}>
        <form className="space-y-4" onSubmit={submit}>
          {edit?.mode === "rename" ? (
            <Field label="Foreman name"><input className="input" required maxLength={60} value={val} onChange={(e) => setVal(e.target.value)} autoFocus /></Field>
          ) : (
            <p className="text-sm text-mute">Delete the foreman <b className="text-bone">{edit?.name}</b>? They have no workers.</p>
          )}
          <ErrorLine text={err} />
          <div className="flex gap-2">
            <button className={edit?.mode === "delete" ? "btn-danger" : "btn-gold"} disabled={busy}>{busy ? "Please wait…" : edit?.mode === "delete" ? "Delete" : "Save name"}</button>
            <button type="button" className="btn-ghost" onClick={() => setEdit(null)}>Cancel</button>
          </div>
        </form>
      </Modal>

      {job && <PrintSheet title={title} groups={job} today={today} windowDays={windowDays} withForeman={false} onDone={donePrint} />}
    </div>
  );
}
