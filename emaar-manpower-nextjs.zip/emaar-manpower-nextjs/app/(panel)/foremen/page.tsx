import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { getSettings, getToday } from "@/lib/settings";
import { listForemen, listWorkers } from "@/lib/workers";
import ForemenManager from "./ForemenManager";

export const metadata: Metadata = { title: "Foremen" };
export const dynamic = "force-dynamic";

export default async function ForemenPage() {
  await requireUser();
  const [settings, today, all, foremen] = await Promise.all([getSettings(), getToday(), listWorkers(), listForemen()]);
  const records: Record<string, number> = {};
  for (const w of all) records[w.foreman_id] = (records[w.foreman_id] ?? 0) + 1;
  return <ForemenManager workers={all.filter((w) => !w.released_on)} foremen={foremen} records={records} today={today} windowDays={settings.expiringDays} title={settings.siteTitle} />;
}
