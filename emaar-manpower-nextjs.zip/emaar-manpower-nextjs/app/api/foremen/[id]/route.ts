import { NextResponse } from "next/server";
import { z } from "zod";
import { requireApi } from "@/lib/auth";
import { fail, handleError, ok, readJson } from "@/lib/api";
import { one, q } from "@/lib/db";
import { logAct } from "@/lib/activity";

type P = { params: Promise<{ id: string }> };
const isId = (id: string) => /^[0-9a-f-]{36}$/i.test(id);

export async function PATCH(req: Request, { params }: P) {
  const u = await requireApi(req, "manager");
  if (u instanceof NextResponse) return u;
  const { id } = await params;
  if (!isId(id)) return fail("Not found", 404);
  try {
    const { name } = z.object({ name: z.string().transform((s) => s.replace(/\s+/g, " ").trim()).pipe(z.string().min(2, "is required").max(60)) }).parse(await readJson(req));
    const old = await one<{ name: string }>("SELECT name FROM foremen WHERE id = $1", [id]);
    if (!old) return fail("Foreman not found.", 404);
    await q("UPDATE foremen SET name = $2 WHERE id = $1", [id, name]);
    await logAct(u.email, "Renamed foreman", `${old.name} -> ${name}`);
    return ok();
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request, { params }: P) {
  const u = await requireApi(req, "admin");
  if (u instanceof NextResponse) return u;
  const { id } = await params;
  if (!isId(id)) return fail("Not found", 404);
  try {
    const n = await one<{ n: number }>("SELECT count(*)::int AS n FROM workers WHERE foreman_id = $1", [id]);
    if ((n?.n ?? 0) > 0) return fail(`This foreman still has ${n!.n} worker record(s), including released ones. Move or delete them first.`, 409);
    const rows = await q<{ name: string }>("DELETE FROM foremen WHERE id = $1 RETURNING name", [id]);
    if (!rows[0]) return fail("Foreman not found.", 404);
    await logAct(u.email, "Deleted foreman", rows[0].name);
    return ok();
  } catch (e) {
    return handleError(e);
  }
}
