import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import { requireApi } from "@/lib/auth";
import { fail, handleError, ok, readJson } from "@/lib/api";
import { one, q } from "@/lib/db";
import { logAct } from "@/lib/activity";

const Body = z.object({
  current: z.string().max(200),
  next: z.string().min(10, "New password must be at least 10 characters").max(200),
});

export async function POST(req: Request) {
  const s = await requireApi(req);
  if (s instanceof NextResponse) return s;
  try {
    const b = Body.parse(await readJson(req));
    const user = await one<{ id: string; password_hash: string }>("SELECT id, password_hash FROM users WHERE id = $1", [s.id]);
    if (!user || !(await bcrypt.compare(b.current, user.password_hash))) return fail("Your current password is incorrect.", 401);
    await q("UPDATE users SET password_hash = $2 WHERE id = $1", [user.id, await bcrypt.hash(b.next, 12)]);
    await logAct(s.email, "Changed own password");
    return ok();
  } catch (e) {
    return handleError(e);
  }
}
