import { NextResponse } from "next/server";
import { requireApi } from "@/lib/auth";
import { fail, handleError, ok, readJson } from "@/lib/api";
import { one, q, tx } from "@/lib/db";
import { WorkerInput, foremanId } from "@/lib/workers";
import { logAct } from "@/lib/activity";

type P = { params: Promise<{ id: string }> };
const isId = (id: string) => /^[0-9a-f-]{36}$/i.test(id);

export async function PATCH(req: Request, { params }: P) {
  const u = await requireApi(req, "manager");
  if (u instanceof NextResponse) return u;
  const { id } = await params;
  if (!isId(id)) return fail("Not found", 404);
  try {
    const w = WorkerInput.parse(await readJson(req));
    const old = await one<{ expiry: string; released_on: string | null }>("SELECT expiry, released_on FROM workers WHERE id = $1", [id]);
    if (!old) return fail("Worker not found.", 404);
    if (old.released_on) return fail("This worker is released. Restore the worker before editing.");
    await tx(async (c) => {
      const fid = await foremanId(c, w.foreman);
      await c.query(
        `UPDATE workers SET iqama=$2, name=$3, position=$4, expiry=$5, shift=$6, foreman_id=$7, nationality=$8, mobile=$9, remarks=$10, updated_at=now() WHERE id=$1`,
        [id, w.iqama, w.name, w.position, w.expiry, w.shift, fid, w.nationality, w.mobile, w.remarks]);
    });
    await logAct(u.email, "Edited worker", `${w.name} (${w.iqama})` + (old.expiry !== w.expiry ? ` expiry ${old.expiry} -> ${w.expiry}` : ""));
    return ok();
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request, { params }: P) {
  const u = await requireApi(req, "admin");
  if (u instanceof NextResponse) return u;
  const { id } = await params;
  if (!isId(id)) return fail("Not found", 404);
  try {
    const rows = await q<{ name: string; iqama: string }>("DELETE FROM workers WHERE id = $1 RETURNING name, iqama", [id]);
    if (!rows[0]) return fail("Worker not found.", 404);
    await logAct(u.email, "Deleted worker", `${rows[0].name} (${rows[0].iqama})`);
    return ok();
  } catch (e) {
    return handleError(e);
  }
}
