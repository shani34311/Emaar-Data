import { NextResponse } from "next/server";
import { z } from "zod";
import { requireApi } from "@/lib/auth";
import { fail, handleError, ok, readJson } from "@/lib/api";
import { one, q, tx } from "@/lib/db";
import { dateStr } from "@/lib/workers";
import { getToday } from "@/lib/settings";
import { fmtDate } from "@/lib/time";
import { logAct } from "@/lib/activity";

type P = { params: Promise<{ id: string; action: string }> };
const isId = (id: string) => /^[0-9a-f-]{36}$/i.test(id);

type W = { id: string; iqama: string; name: string; expiry: string; released_on: string | null };
const load = (id: string) => one<W>("SELECT id, iqama, name, expiry, released_on FROM workers WHERE id = $1", [id]);

/** Iqama update history for one worker. */
export async function GET(req: Request, { params }: P) {
  const u = await requireApi(req);
  if (u instanceof NextResponse) return u;
  const { id, action } = await params;
  if (!isId(id) || action !== "history") return fail("Not found", 404);
  const rows = await q("SELECT old_expiry, new_expiry, renewed_on, by_user FROM renewals WHERE worker_id = $1 ORDER BY created_at DESC", [id]);
  return ok({ history: rows });
}

export async function POST(req: Request, { params }: P) {
  const u = await requireApi(req, "manager");
  if (u instanceof NextResponse) return u;
  const { id, action } = await params;
  if (!isId(id)) return fail("Not found", 404);
  try {
    const w = await load(id);
    if (!w) return fail("Worker not found.", 404);
    const body = await readJson(req);

    if (action === "renew") {
      const { new_expiry } = z.object({ new_expiry: dateStr }).parse(body);
      if (w.released_on) return fail("This worker is released.");
      const today = await getToday();
      if (new_expiry <= today) return fail(`New expiry date must be after today (${fmtDate(today)}).`);
      if (new_expiry <= w.expiry) return fail(`New expiry date must be later than the current expiry (${fmtDate(w.expiry)}).`);
      await tx(async (c) => {
        await c.query("INSERT INTO renewals (worker_id, old_expiry, new_expiry, renewed_on, by_user) VALUES ($1,$2,$3,$4,$5)", [id, w.expiry, new_expiry, today, u.email]);
        await c.query("UPDATE workers SET expiry = $2, updated_at = now() WHERE id = $1", [id, new_expiry]);
      });
      await logAct(u.email, "Updated iqama", `${w.name} (${w.iqama}) ${w.expiry} -> ${new_expiry}`);
      return ok();
    }

    if (action === "release") {
      const b = z.object({ date: dateStr, reason: z.string().transform((s) => s.replace(/\s+/g, " ").trim()).pipe(z.string().min(2, "is required").max(200)) }).parse(body);
      if (w.released_on) return fail("This worker is already released.");
      await q("UPDATE workers SET released_on = $2, release_reason = $3, updated_at = now() WHERE id = $1", [id, b.date, b.reason]);
      await logAct(u.email, "Released worker", `${w.name} (${w.iqama}) on ${b.date}: ${b.reason}`);
      return ok();
    }

    if (action === "restore") {
      if (!w.released_on) return fail("This worker is already active.");
      const dup = await one("SELECT 1 FROM workers WHERE iqama = $1 AND released_on IS NULL AND id <> $2", [w.iqama, id]);
      if (dup) return fail("Cannot restore: this iqama number is already active.");
      await q("UPDATE workers SET released_on = NULL, release_reason = NULL, updated_at = now() WHERE id = $1", [id]);
      await logAct(u.email, "Restored worker", `${w.name} (${w.iqama})`);
      return ok();
    }

    return fail("Not found", 404);
  } catch (e) {
    return handleError(e);
  }
}
