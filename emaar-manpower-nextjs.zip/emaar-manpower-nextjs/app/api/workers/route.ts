import { NextResponse } from "next/server";
import { requireApi } from "@/lib/auth";
import { handleError, ok, readJson } from "@/lib/api";
import { tx } from "@/lib/db";
import { WorkerInput, foremanId } from "@/lib/workers";
import { logAct } from "@/lib/activity";

export async function POST(req: Request) {
  const u = await requireApi(req, "manager");
  if (u instanceof NextResponse) return u;
  try {
    const w = WorkerInput.parse(await readJson(req));
    const id = await tx(async (c) => {
      const fid = await foremanId(c, w.foreman);
      const r = await c.query(
        `INSERT INTO workers (iqama, name, position, expiry, shift, foreman_id, nationality, mobile, remarks)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
        [w.iqama, w.name, w.position, w.expiry, w.shift, fid, w.nationality, w.mobile, w.remarks]);
      return r.rows[0].id as string;
    });
    await logAct(u.email, "Added worker", `${w.name} (${w.iqama})`);
    return ok({ id }, 201);
  } catch (e) {
    return handleError(e);
  }
}
