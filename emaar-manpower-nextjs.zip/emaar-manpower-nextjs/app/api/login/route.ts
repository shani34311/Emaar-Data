import bcrypt from "bcryptjs";
import { z } from "zod";
import { one, q } from "@/lib/db";
import { createSessionCookie } from "@/lib/auth";
import { fail, handleError, ok, readJson } from "@/lib/api";
import { logAct } from "@/lib/activity";

const Body = z.object({ email: z.string().trim().toLowerCase().max(120), password: z.string().max(200) });
const MAX_TRIES = 8;
const WINDOW_MIN = 15;
let dummy: string | null = null; // so failed logins take the same time whether or not the email exists

export async function POST(req: Request) {
  try {
    const { email, password } = Body.parse(await readJson(req));
    const ip = (req.headers.get("x-forwarded-for") || "local").split(",")[0].trim();
    const key = `${ip}|${email}`;

    // Brute-force protection: max 8 failed attempts per 15 minutes per IP + email.
    const att = await one<{ count: number; fresh: boolean }>(
      `SELECT count, window_start > now() - interval '${WINDOW_MIN} minutes' AS fresh FROM login_attempts WHERE key = $1`, [key]);
    if (att && att.fresh && att.count >= MAX_TRIES) return fail(`Too many attempts. Please wait ${WINDOW_MIN} minutes and try again.`, 429);

    const user = await one<{ id: string; email: string; password_hash: string; active: boolean }>("SELECT id, email, password_hash, active FROM users WHERE email = $1", [email]);
    const good = user ? await bcrypt.compare(password, user.password_hash) : await bcrypt.compare(password, (dummy ??= await bcrypt.hash("not-a-real-password", 12))).then(() => false);
    if (!user || !good) {
      await q(
        `INSERT INTO login_attempts (key, count, window_start) VALUES ($1, 1, now())
         ON CONFLICT (key) DO UPDATE SET
           count = CASE WHEN login_attempts.window_start > now() - interval '${WINDOW_MIN} minutes' THEN login_attempts.count + 1 ELSE 1 END,
           window_start = CASE WHEN login_attempts.window_start > now() - interval '${WINDOW_MIN} minutes' THEN login_attempts.window_start ELSE now() END`,
        [key]
      );
      return fail("Incorrect email or password.", 401);
    }
    if (!user.active) return fail("This account is disabled. Ask the administrator.", 403);
    await q("DELETE FROM login_attempts WHERE key = $1", [key]);
    await q("UPDATE users SET last_login = now() WHERE id = $1", [user.id]);
    await createSessionCookie({ sub: user.id });
    await logAct(user.email, "Signed in");
    return ok();
  } catch (e) {
    return handleError(e);
  }
}
