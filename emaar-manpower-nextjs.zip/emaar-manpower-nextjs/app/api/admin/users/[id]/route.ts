import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { requireApi } from "@/lib/auth";
import { fail, handleError, ok, readJson } from "@/lib/api";
import { one, q } from "@/lib/db";
import { UserInput, otherActiveAdmins } from "@/lib/users";
import { logAct } from "@/lib/activity";

type P = { params: Promise<{ id: string }> };
const isId = (id: string) => /^[0-9a-f-]{36}$/i.test(id);

export async function PATCH(req: Request, { params }: P) {
  const me = await requireApi(req, "admin");
  if (me instanceof NextResponse) return me;
  const { id } = await params;
  if (!isId(id)) return fail("Not found", 404);
  try {
    const b = UserInput.parse(await readJson(req));
    const t = await one<{ role: string }>("SELECT role FROM users WHERE id = $1", [id]);
    if (!t) return fail("User not found.", 404);
    if (id === me.id && (b.role !== "admin" || !b.active)) return fail("You cannot remove your own administrator role or disable your own account.");
    if (t.role === "admin" && (b.role !== "admin" || !b.active) && (await otherActiveAdmins(id)) === 0) return fail("At least one active administrator is required.");
    await q("UPDATE users SET email=$2, name=$3, role=$4, active=$5 WHERE id=$1", [id, b.email, b.name, b.role, b.active]);
    if (b.password) await q("UPDATE users SET password_hash = $2 WHERE id = $1", [id, await bcrypt.hash(b.password, 12)]);
    await logAct(me.email, "Edited user", `${b.email} (${b.role}${b.active ? "" : ", disabled"}${b.password ? ", password reset" : ""})`);
    return ok();
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(req: Request, { params }: P) {
  const me = await requireApi(req, "admin");
  if (me instanceof NextResponse) return me;
  const { id } = await params;
  if (!isId(id)) return fail("Not found", 404);
  try {
    if (id === me.id) return fail("You cannot delete your own account.");
    const t = await one<{ email: string; role: string }>("SELECT email, role FROM users WHERE id = $1", [id]);
    if (!t) return fail("User not found.", 404);
    if (t.role === "admin" && (await otherActiveAdmins(id)) === 0) return fail("At least one active administrator is required.");
    await q("DELETE FROM users WHERE id = $1", [id]);
    await logAct(me.email, "Deleted user", t.email);
    return ok();
  } catch (e) {
    return handleError(e);
  }
}
