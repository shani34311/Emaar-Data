import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { requireApi } from "@/lib/auth";
import { fail, handleError, ok, readJson } from "@/lib/api";
import { q } from "@/lib/db";
import { UserInput } from "@/lib/users";
import { logAct } from "@/lib/activity";

export async function POST(req: Request) {
  const u = await requireApi(req, "admin");
  if (u instanceof NextResponse) return u;
  try {
    const b = UserInput.parse(await readJson(req));
    if (!b.password) return fail("Password is required for a new user (at least 10 characters).");
    await q("INSERT INTO users (email, name, password_hash, role, active) VALUES ($1,$2,$3,$4,$5)", [b.email, b.name, await bcrypt.hash(b.password, 12), b.role, b.active]);
    await logAct(u.email, "Added user", `${b.email} (${b.role})`);
    return ok({}, 201);
  } catch (e) {
    return handleError(e);
  }
}
