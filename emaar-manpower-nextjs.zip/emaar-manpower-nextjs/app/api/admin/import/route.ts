import { NextResponse } from "next/server";
import { requireApi } from "@/lib/auth";
import { fail, handleError, ok, readJson } from "@/lib/api";
import { tx } from "@/lib/db";
import { WorkerInput, foremanId } from "@/lib/workers";
import { isDateStr } from "@/lib/time";
import { logAct } from "@/lib/activity";

const MAX = 5000;
const str = (v: unknown) => (typeof v === "string" || typeof v === "number" ? String(v).trim() : "");

export async function POST(req: Request) {
  const u = await requireApi(req, "admin");
  if (u instanceof NextResponse) return u;
  try {
    const body = await readJson(req);
    const records: unknown = body?.records;
    if (!Array.isArray(records) || records.length === 0) return fail("No records found in the file.");
    if (records.length > MAX) return fail(`Too many records in one import (limit ${MAX.toLocaleString()}). Split the file.`);

    let added = 0, skipped = 0;
    const errors: string[] = [];
    await tx(async (c) => {
      const foremen = new Map<string, string>();
      for (let i = 0; i < records.length; i++) {
        const row = i + 1;
        const r = records[i] as Record<string, unknown>;
        if (!r || typeof r !== "object") { errors.push(`Row ${row}: not a valid record.`); continue; }
        // Accept the new format and the first single-file version of the dashboard.
        const g = (a: string, b: string) => r[a] ?? r[b];
        const parsed = WorkerInput.safeParse({
          iqama: str(r.iqama), name: str(r.name), position: str(g("position", "pos")), expiry: str(g("expiry", "exp")), shift: /night/i.test(str(r.shift)) ? "Night shift" : "Day shift",
          foreman: str(g("foreman", "fore")), nationality: str(r.nationality), mobile: str(r.mobile), remarks: str(r.remarks),
        });
        if (!parsed.success) {
          const f = parsed.error.issues[0];
          errors.push(`Row ${row}: ${String(f.path[0] ?? "")} ${f.message}`.trim());
          continue;
        }
        const w = parsed.data;
        const rel = str(g("released_on", "rel"));
        const reason = str(g("release_reason", "reason")).slice(0, 200);
        if (rel && !isDateStr(rel)) { errors.push(`Row ${row}: release date is not valid.`); continue; }

        const dup = rel
          ? await c.query("SELECT 1 FROM workers WHERE iqama = $1 AND released_on = $2", [w.iqama, rel])
          : await c.query("SELECT 1 FROM workers WHERE iqama = $1 AND released_on IS NULL", [w.iqama]);
        if (dup.rowCount) { skipped++; continue; }

        const fk = w.foreman.toLowerCase();
        let fid = foremen.get(fk);
        if (!fid) { fid = await foremanId(c, w.foreman); foremen.set(fk, fid); }
        const ins = await c.query(
          `INSERT INTO workers (iqama, name, position, expiry, shift, foreman_id, nationality, mobile, remarks, released_on, release_reason)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
          [w.iqama, w.name, w.position, w.expiry, w.shift, fid, w.nationality, w.mobile, w.remarks, rel || null, rel ? (reason || "Imported") : null]);
        const wid = ins.rows[0].id as string;

        const ren = r.renewals;
        if (Array.isArray(ren)) {
          for (const x of ren as Record<string, unknown>[]) {
            if (x && isDateStr(str(x.new_expiry)) && isDateStr(str(x.renewed_on))) {
              await c.query("INSERT INTO renewals (worker_id, old_expiry, new_expiry, renewed_on, by_user) VALUES ($1,$2,$3,$4,$5)",
                [wid, isDateStr(str(x.old_expiry)) ? str(x.old_expiry) : null, str(x.new_expiry), str(x.renewed_on), str(x.by).slice(0, 80) || "import"]);
            }
          }
        } else if (isDateStr(str(r.prevExp)) && isDateStr(str(r.renewed))) {
          await c.query("INSERT INTO renewals (worker_id, old_expiry, new_expiry, renewed_on, by_user) VALUES ($1,$2,$3,$4,'import')", [wid, str(r.prevExp), w.expiry, str(r.renewed)]);
        }
        added++;
      }
    });
    await logAct(u.email, "Imported workers", `${added} added, ${skipped} skipped, ${errors.length} with errors`);
    return ok({ added, skipped, invalid: errors.length, errors: errors.slice(0, 20) });
  } catch (e) {
    return handleError(e);
  }
}
