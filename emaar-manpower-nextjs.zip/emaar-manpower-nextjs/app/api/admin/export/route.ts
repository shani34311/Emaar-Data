import { NextResponse } from "next/server";
import { requireApi } from "@/lib/auth";
import { q } from "@/lib/db";
import { getSettings, getToday } from "@/lib/settings";
import { listWorkers } from "@/lib/workers";
import { logAct } from "@/lib/activity";

export async function GET(req: Request) {
  const u = await requireApi(req, "admin");
  if (u instanceof NextResponse) return u;
  const [workers, settings, today] = await Promise.all([listWorkers(), getSettings(), getToday()]);
  const ren = await q<{ worker_id: string; old_expiry: string | null; new_expiry: string; renewed_on: string; by_user: string | null }>(
    "SELECT worker_id, old_expiry, new_expiry, renewed_on, by_user FROM renewals ORDER BY created_at");
  const by = new Map<string, any[]>();
  for (const r of ren) {
    if (!by.has(r.worker_id)) by.set(r.worker_id, []);
    by.get(r.worker_id)!.push({ old_expiry: r.old_expiry, new_expiry: r.new_expiry, renewed_on: r.renewed_on, by: r.by_user });
  }
  const out = {
    format: "emaar-manpower-backup", version: 1, exported_at: new Date().toISOString(), settings,
    workers: workers.map((w) => ({
      iqama: w.iqama, name: w.name, position: w.position, expiry: w.expiry, shift: w.shift, foreman: w.foreman, nationality: w.nationality,
      mobile: w.mobile, remarks: w.remarks, released_on: w.released_on, release_reason: w.release_reason, renewals: by.get(w.id) ?? [],
    })),
  };
  await logAct(u.email, "Downloaded backup");
  return new NextResponse(JSON.stringify(out, null, 1), {
    headers: { "Content-Type": "application/json; charset=utf-8", "Content-Disposition": `attachment; filename="emaar-manpower-backup-${today}.json"`, "Cache-Control": "no-store" },
  });
}
