import { NextResponse } from "next/server";
import { z } from "zod";
import { requireApi } from "@/lib/auth";
import { handleError, ok, readJson } from "@/lib/api";
import { q } from "@/lib/db";
import { TIMEZONES } from "@/lib/types";
import { logAct } from "@/lib/activity";

const Body = z.object({
  siteTitle: z.string().transform((s) => s.replace(/\s+/g, " ").trim()).pipe(z.string().min(3, "must be at least 3 characters").max(80)),
  expiringDays: z.coerce.number().int().min(1, "must be between 1 and 180").max(180, "must be between 1 and 180"),
  timezone: z.enum(TIMEZONES as [string, ...string[]]),
});

export async function POST(req: Request) {
  const u = await requireApi(req, "admin");
  if (u instanceof NextResponse) return u;
  try {
    const v = Body.parse(await readJson(req));
    await q("INSERT INTO settings (id, value) VALUES ('main', $1) ON CONFLICT (id) DO UPDATE SET value = $1", [JSON.stringify(v)]);
    await logAct(u.email, "Changed settings", `Expiring window ${v.expiringDays} days, time zone ${v.timezone}`);
    return ok();
  } catch (e) {
    return handleError(e);
  }
}
