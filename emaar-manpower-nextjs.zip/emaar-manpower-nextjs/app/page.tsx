import Link from "next/link";
import Logo from "@/components/Logo";
import { getUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function Home() {
  let signedIn = false, win = 30, title = "EMAAR Manpower Dashboard (Areena)";
  try {
    signedIn = !!(await getUser());
    const s = await getSettings();
    win = s.expiringDays; title = s.siteTitle;
  } catch {}
  const cta = signedIn ? { href: "/dashboard", text: "Open the dashboard" } : { href: "/login", text: "Staff sign in" };

  const states = [
    { name: "Valid", text: `The iqama has more than ${win} days left.`, dot: "bg-bull", ring: "ring-bull/30" },
    { name: "Expiring soon", text: `The iqama expires within the next ${win} days. Time to renew.`, dot: "bg-warn", ring: "ring-warn/30" },
    { name: "Expired", text: "The iqama is no longer valid and needs urgent action.", dot: "bg-bear", ring: "ring-bear/30" },
  ];
  const features = [
    ["Iqama alerts", "See how many iqama are valid, expiring in the next 30 days or already expired, and who needs action first."],
    ["Foremen and shifts", "Every worker belongs to a foreman and a day or night shift. Open one foreman and see exactly their team."],
    ["Print and backup", "A separate printed sheet for each foreman, PDF and CSV downloads, and a full backup file for safe keeping."],
  ];

  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
      <header className="wrap relative flex items-center justify-between py-6">
        <Logo />
        <Link href={cta.href} className="btn-ghost btn-sm">{cta.text}</Link>
      </header>

      <main className="wrap relative pb-20 pt-10 sm:pt-16">
        <div className="grid items-center gap-12 lg:grid-cols-[1.25fr_1fr]">
          <div className="reveal">
            <h1 className="h-display text-4xl text-bone sm:text-6xl">{title}</h1>
            <p className="mt-5 max-w-xl text-lg leading-8 text-mute">
              Keep every worker’s iqama under control. Add your workers once, and the dashboard shows who is valid, who is expiring soon and who has expired.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href={cta.href} className="btn-gold">{cta.text}</Link>
            </div>
            <p className="mt-4 text-sm text-dim">Private system. You need an account created by your administrator.</p>
          </div>

          <div className="card reveal space-y-3 p-5 sm:p-6" style={{ animationDelay: "0.1s" }}>
            <h2 className="h-display text-xl text-bone">How the iqama status works</h2>
            {states.map((s) => (
              <div key={s.name} className={`flex items-start gap-3 rounded-xl bg-ink-2 p-4 ring-1 ${s.ring}`}>
                <span className={`mt-1.5 h-3 w-3 shrink-0 rounded-full ${s.dot}`} />
                <div>
                  <p className="font-bold text-bone">{s.name}</p>
                  <p className="text-sm text-mute">{s.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-20 grid gap-4 md:grid-cols-3">
          {features.map(([t, d]) => (
            <div key={t} className="card p-6">
              <div className="gold-rule mb-5" />
              <h3 className="h-display text-xl text-bone">{t}</h3>
              <p className="mt-2 text-sm leading-6 text-mute">{d}</p>
            </div>
          ))}
        </div>
      </main>

      <footer className="wrap relative border-t border-line py-6 text-xs text-dim">EMAAR Manpower Dashboard (Areena)</footer>
    </div>
  );
}
