#!/bin/bash
# EMAAR Manpower Dashboard (Areena) · local test (double-click on Mac)
cd "$(dirname "$0")"
echo ""
echo " EMAAR Manpower Dashboard (Areena)"
echo " ================================="
if ! command -v node >/dev/null 2>&1; then
  echo " Node.js is not installed yet. Opening nodejs.org — install the LTS version, then double-click this file again."
  open "https://nodejs.org/en/download"
  read -p " Press Enter to close…"
  exit 1
fi
if [ ! -f node_modules/@electric-sql/pglite/package.json ]; then
  echo " First time setup: downloading what the website needs (2–5 minutes)…"
  npm install --no-audit --no-fund || { read -p " Download failed. Press Enter to close…"; exit 1; }
fi
node scripts/local.mjs
