@echo off
title EMAAR Manpower Dashboard (local test)
cd /d "%~dp0"
echo.
echo  EMAAR Manpower Dashboard (Areena)
echo  =================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js is not installed yet.
  echo  Your browser will now open nodejs.org - download the LTS version,
  echo  install it ^(keep clicking Next^), then double-click this file again.
  start "" https://nodejs.org/en/download
  echo.
  pause
  exit /b
)
if not exist "node_modules\@electric-sql\pglite\package.json" (
  echo  First time setup: downloading what the website needs.
  echo  This takes 2-5 minutes. Please wait...
  echo.
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo  Download failed. Check your internet connection and try again.
    pause
    exit /b
  )
)
node scripts\local.mjs
echo.
pause
