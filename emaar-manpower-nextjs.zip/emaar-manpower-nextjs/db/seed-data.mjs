// Shared by db/setup.mjs and lib/settings.ts

export const DEFAULT_SETTINGS = {
  siteTitle: "EMAAR Manpower Dashboard (Areena)",
  expiringDays: 30,
  timezone: "Asia/Riyadh",
};

// Fictional sample workers, only used for the local test copy (never on the live website).
export const DEMO_WORKERS = [
  // [iqama, name, position, daysFromToday, shift, foreman, nationality]
  ["2400000011", "Ahmed Raza", "Electrician", 210, "Day shift", "Imran Malik", "Pakistan"],
  ["2400000012", "Bilal Hussain", "Welder", 18, "Night shift", "Imran Malik", "Pakistan"],
  ["2400000013", "Chaudhry Salman", "Pipe Fitter", -12, "Day shift", "Imran Malik", "Pakistan"],
  ["2400000014", "Dawood Khan", "Rigger", 75, "Day shift", "Imran Malik", "Pakistan"],
  ["2400000015", "Essa Gul", "Helper", 27, "Night shift", "Imran Malik", "Pakistan"],
  ["2400000021", "Farhan Ali", "Mason", 310, "Day shift", "Sajid Mehmood", "Pakistan"],
  ["2400000022", "Gulzar Ahmad", "Carpenter", 9, "Day shift", "Sajid Mehmood", "Pakistan"],
  ["2400000023", "Hamza Shah", "Steel Fixer", -40, "Night shift", "Sajid Mehmood", "Pakistan"],
  ["2400000024", "Irfan Ullah", "Scaffolder", 150, "Night shift", "Sajid Mehmood", "Pakistan"],
  ["2400000031", "Jamil Akhtar", "Painter", 95, "Day shift", "Tariq Anwar", "India"],
  ["2400000032", "Kamran Abbas", "Plumber", 22, "Day shift", "Tariq Anwar", "India"],
  ["2400000033", "Luqman Hakim", "HVAC Technician", 400, "Night shift", "Tariq Anwar", "Bangladesh"],
  ["2400000034", "Mansoor Iqbal", "Driver", -3, "Day shift", "Tariq Anwar", "Pakistan"],
  ["2400000035", "Naveed Akram", "Crane Operator", 60, "Night shift", "Tariq Anwar", "Pakistan"],
];
