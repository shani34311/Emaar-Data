-- EMAAR Manpower Dashboard (Areena) · database schema (PostgreSQL / Supabase)
-- Safe to run more than once. It is run automatically on every deploy.

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL DEFAULT 'User',
  password_hash text NOT NULL,
  role text NOT NULL DEFAULT 'viewer' CHECK (role IN ('admin','manager','viewer')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login timestamptz
);

CREATE TABLE IF NOT EXISTS foremen (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS foremen_name_ux ON foremen (lower(name));

CREATE TABLE IF NOT EXISTS workers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  iqama text NOT NULL CHECK (iqama ~ '^\d{10}$'),
  name text NOT NULL,
  position text NOT NULL,
  expiry text NOT NULL CHECK (expiry ~ '^\d{4}-\d{2}-\d{2}$'),   -- iqama expiry date (YYYY-MM-DD)
  shift text NOT NULL CHECK (shift IN ('Day shift','Night shift')),
  foreman_id uuid NOT NULL REFERENCES foremen(id) ON DELETE RESTRICT,
  nationality text NOT NULL DEFAULT '',
  mobile text NOT NULL DEFAULT '',
  remarks text NOT NULL DEFAULT '',
  released_on text CHECK (released_on IS NULL OR released_on ~ '^\d{4}-\d{2}-\d{2}$'),
  release_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- An iqama number can only be active once (released records may repeat it, e.g. a worker who comes back).
CREATE UNIQUE INDEX IF NOT EXISTS workers_active_iqama_ux ON workers (iqama) WHERE released_on IS NULL;
CREATE INDEX IF NOT EXISTS workers_foreman_idx ON workers (foreman_id);
CREATE INDEX IF NOT EXISTS workers_expiry_idx ON workers (expiry);

CREATE TABLE IF NOT EXISTS renewals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id uuid NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  old_expiry text,
  new_expiry text NOT NULL,
  renewed_on text NOT NULL,
  by_user text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS renewals_worker_idx ON renewals (worker_id);

CREATE TABLE IF NOT EXISTS activity (
  id bigserial PRIMARY KEY,
  at timestamptz NOT NULL DEFAULT now(),
  user_email text NOT NULL DEFAULT '-',
  action text NOT NULL,
  detail text NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS settings (
  id text PRIMARY KEY,
  value jsonb NOT NULL
);

CREATE TABLE IF NOT EXISTS login_attempts (
  key text PRIMARY KEY,
  count int NOT NULL DEFAULT 0,
  window_start timestamptz NOT NULL DEFAULT now()
);
