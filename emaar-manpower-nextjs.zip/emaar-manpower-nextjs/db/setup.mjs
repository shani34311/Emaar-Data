// Creates the database tables and the first administrator account.
// Runs automatically on every Vercel deploy (see "vercel-build" in package.json).
// Safe to run many times: it never overwrites data you entered.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";
import bcrypt from "bcryptjs";
import { DEFAULT_SETTINGS, DEMO_WORKERS } from "./seed-data.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const url = process.env.DIRECT_URL || process.env.DATABASE_URL;
if (!url) {
  console.error("✗ DATABASE_URL is not set. Add it in Vercel → Settings → Environment Variables.");
  process.exit(1);
}

const client = new pg.Client({ connectionString: url, ssl: /localhost|127\.0\.0\.1/.test(url) ? false : { rejectUnauthorized: false } });

const TABLE_NAMES = ["users", "foremen", "workers", "renewals", "activity", "settings", "login_attempts"];

async function count(table) {
  const r = await client.query(`SELECT count(*)::int AS n FROM ${table}`);
  return r.rows[0].n;
}

const iso = (d) => d.toISOString().slice(0, 10);
const plusDays = (n) => iso(new Date(Date.now() + n * 864e5));

async function main() {
  await client.connect();
  await client.query(fs.readFileSync(path.join(here, "schema.sql"), "utf8"));
  console.log("✓ Database tables ready");

  // Lock tables against Supabase's public Data API. The website connects directly and is not affected.
  for (const t of TABLE_NAMES) await client.query(`ALTER TABLE ${t} ENABLE ROW LEVEL SECURITY`);

  // First administrator
  const email = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || "";
  if ((await count("users")) === 0) {
    if (email && password) {
      await client.query("INSERT INTO users (email, name, password_hash, role) VALUES ($1, 'Administrator', $2, 'admin')", [email, await bcrypt.hash(password, 12)]);
      console.log(`✓ Administrator account created for ${email}`);
    } else {
      console.log("! No administrator yet — set ADMIN_EMAIL and ADMIN_PASSWORD and deploy again.");
    }
  }

  await client.query("INSERT INTO settings (id, value) VALUES ('main', $1) ON CONFLICT (id) DO NOTHING", [JSON.stringify(DEFAULT_SETTINGS)]);

  // Sample workers: only when SEED_DEMO=1 (the local test copy) and the list is empty.
  if (process.env.SEED_DEMO === "1" && (await count("workers")) === 0) {
    const ids = new Map();
    for (const [iqama, name, position, days, shift, foreman, nationality] of DEMO_WORKERS) {
      let fid = ids.get(foreman);
      if (!fid) {
        fid = (await client.query("INSERT INTO foremen (name) VALUES ($1) RETURNING id", [foreman])).rows[0].id;
        ids.set(foreman, fid);
      }
      await client.query(
        "INSERT INTO workers (iqama, name, position, expiry, shift, foreman_id, nationality, remarks) VALUES ($1,$2,$3,$4,$5,$6,$7,'Sample worker')",
        [iqama, name, position, plusDays(days), shift, fid, nationality]
      );
    }
    console.log(`✓ ${DEMO_WORKERS.length} sample workers added (local test copy only)`);
  }

  await client.end();
  console.log("✓ Setup complete");
}

main().catch(async (e) => {
  console.error("✗ Database setup failed:", e.message);
  try { await client.end(); } catch {}
  process.exit(1);
});
